import pandas as pd
import os

def extract_unique_values(file_path, column_names, output_path=None):
    """
    从 CSV 或 Excel 文件中提取多个列的唯一值，并可选择保存到新文件。

    参数:
    file_path (str): 输入文件路径 (.csv 或 .xlsx/.xls)
    column_names (list): 要提取唯一值的列名列表
    output_path (str): 输出文件路径（可选，默认不保存）

    返回:
    dict: 每个列对应的唯一值列表
    """
    # 判断文件类型
    ext = os.path.splitext(file_path)[1].lower()
    if ext == '.csv':
        df = pd.read_csv(file_path)
    elif ext in ['.xlsx', '.xls']:
        df = pd.read_excel(file_path)
    else:
        raise ValueError("不支持的文件类型，请使用 CSV 或 Excel 文件。")

    # 检查列是否存在
    missing_cols = [col for col in column_names if col not in df.columns]
    if missing_cols:
        raise ValueError(f"缺少列: {missing_cols}")

    # 提取每列的唯一值
    unique_dict = {col: df[col].dropna().unique().tolist() for col in column_names}

    # 如果需要保存
    if output_path:
        max_len = max(len(v) for v in unique_dict.values())
        data = {col: v + [None]*(max_len - len(v)) for col, v in unique_dict.items()}
        pd.DataFrame(data).to_excel(output_path, index=False)

    return unique_dict


# 示例调用
file_path = '/Users/zhengruinan/Desktop/sales.csv'
column_names = ["企业", "品牌", "车型", "款型", "车辆型号", "排量",
                "燃料", "变速器", "车身类型", "版本年份", "款型_剩余", "mix3"]
output_path = '/Users/zhengruinan/Desktop/unique-ori.xlsx'

result = extract_unique_values(file_path, column_names, output_path)

print("finish")