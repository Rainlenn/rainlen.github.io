import pandas as pd
import re

# 1. 定义文件路径
file_path = '/Users/zhengruinan/Desktop/sales_data_with_price_strict.csv'
output_path = '/Users/zhengruinan/Desktop/sales_data_1119.csv'

# 2. 读取CSV文件
# 尝试使用gbk或gb18030编码读取，因为数据中包含中文
try:
    df = pd.read_csv(file_path, encoding='utf-8')
except UnicodeDecodeError:
    try:
        df = pd.read_csv(file_path, encoding='gbk')
    except UnicodeDecodeError:
        df = pd.read_csv(file_path, encoding='gb18030')

# 3. 第一步：删去'厂商指导价(元)'中为' '（即空值）的数据行
# 观察数据，空值可能为' '（空格字符串）或NaN。
# 首先，将' '替换为NaN，然后使用dropna()删除NaN值。
# 此外，观察到有些空值是空字符串''，需要处理。
# 假设空值可能为：' ', '', NaN
df['厂商指导价(元)'] = df['厂商指导价(元)'].replace(' ', pd.NA)
df['厂商指导价(元)'] = df['厂商指导价(元)'].replace('', pd.NA)
df.dropna(subset=['厂商指导价(元)'], inplace=True)

# 4. 第二步：对D列‘市’进行统一字段处理
# 统一规则：
# - 优先使用最完整的行政区划名称。
# - 常见的后缀如“市”、“地区”、“自治州”、“盟”等，如果缺失则补全，如果存在则保留。
# - 针对用户提供的具体例子进行处理，并推广到类似情况。

# 统一化映射字典
# 这是一个不完整的映射，但基于用户提供的例子和常见情况进行构建。
# 完整的映射需要一个全国行政区划数据库，这里采用启发式规则和部分手动映射。
city_mapping = {
    '厦门': '厦门市',
    '安康': '安康市',
    '阿克苏': '阿克苏地区',
    '大理': '大理白族自治州',
    '阿拉善': '阿拉善盟',
    # 推广规则：如果城市名以“市”结尾，则统一为“市”
    # 如果城市名不以“市”、“地区”、“自治州”、“盟”等结尾，但可以推断，则进行统一。
    # 由于数据量大，无法手动穷举，采用更通用的函数式处理。
}

def standardize_city_name(city):
    if pd.isna(city):
        return city
    city = str(city).strip()
    
    # 1. 优先使用手动映射
    if city in city_mapping:
        return city_mapping[city]

    # 2. 启发式规则：
    # 规则 2.1: 城市名中包含“地区”、“自治州”、“盟”等完整后缀的，保留最长的名称。
    # 例如：'大理' vs '大理白族自治州' -> '大理白族自治州'
    # 这是一个挑战，因为我们只有当前行的数据。为了实现这个，我们需要先收集所有不规范的城市名。
    # 由于我们不能在脚本中进行交互式分析，我们采用最直接的后缀补全/统一逻辑。

    # 规则 2.2: 补全“市”后缀
    # 很多城市名只是城市名本身，没有“市”字。
    # 排除直辖市（如北京、上海、天津、重庆）和特殊行政区（如香港、澳门）
    # 排除已包含完整行政区划后缀的名称
    
    # 常见行政区划后缀
    suffixes = ['市', '地区', '自治州', '盟', '旗', '县', '区']
    
    # 检查是否已包含后缀
    has_suffix = any(city.endswith(suffix) for suffix in suffixes)
    
    # 简单化处理：如果城市名不包含任何常见后缀，且不是直辖市/特殊行政区，则尝试补全“市”。
    # 这是一个有风险的简化，但可以处理大部分“城市名” vs “城市名市”的情况。
    if not has_suffix:
        # 这是一个非常粗略的判断，但可以处理用户例子中的 '厦门' -> '厦门市'
        # 更好的做法是基于一个完整的行政区划列表进行匹配和替换。
        # 考虑到用户需求，我们先进行一个基于正则的通用替换，以统一“简称”和“全称”
        
        # 尝试移除“市”、“地区”、“自治州”、“盟”等后缀，得到一个“核心名”
        core_name = city
        for suffix in suffixes:
            if city.endswith(suffix):
                core_name = city[:-len(suffix)]
                break
        
        # 假设所有以“核心名”开头的城市名都应该统一为最长的那个。
        # 由于我们无法在单行处理中实现全局查找最长名称，我们只能依赖用户提供的映射和简单的后缀补全。
        
        # 针对用户例子：'阿克苏'和'阿克苏地区'
        # 如果城市名是简称，且其全称在数据集中出现，我们应该统一。
        # 再次强调，没有完整的行政区划数据，这个任务很难完美完成。
        
        # 最终简化策略：
        # 1. 使用手动映射。
        # 2. 对于不带后缀的城市名，如果它不是直辖市，则统一加上“市”后缀。
        #    直辖市/特殊行政区列表
        special_cities = ['北京', '上海', '天津', '重庆', '香港', '澳门']
        if city not in special_cities and not has_suffix:
            # 检查是否是用户提供的特殊简称
            if city == '阿克苏':
                return '阿克苏地区'
            elif city == '大理':
                return '大理白族自治州'
            elif city == '阿拉善':
                return '阿拉善盟'
            # 否则，统一加上“市”
            return city + '市'
            
    return city

# 5. 应用城市名称标准化函数
# 为了实现“最长名称”的统一，我们需要先找出所有城市名，然后建立一个更完善的映射。
# 由于数据量大，我们不能在脚本中直接打印所有城市名让用户来完善映射。
# 我们将采用一个两阶段策略：
# 阶段一：初步清洗，将所有城市名去重并打印出来，让用户确认（但用户要求直接运行）。
# 阶段二：在不交互的情况下，我们只能依赖启发式规则。

# 重新定义一个更智能的标准化函数，它将尝试从数据集中发现“全称”
def smart_standardize_city_name(df):
    # 收集所有城市名
    all_cities = df['市'].astype(str).str.strip().unique()
    
    # 建立一个基于“核心名”到“最长全称”的映射
    standard_map = {}
    
    # 常见行政区划后缀
    suffixes = ['市', '地区', '自治州', '盟', '旗', '县', '区']
    
    for city in all_cities:
        if not city: continue
        
        # 尝试找到核心名
        core_name = city
        for suffix in suffixes:
            if city.endswith(suffix):
                # 移除后缀
                core_name = city[:-len(suffix)]
                break
        
        # 如果核心名是空，跳过
        if not core_name: continue
        
        # 查找所有以该核心名开头的城市名
        related_cities = [c for c in all_cities if c.startswith(core_name)]
        
        # 找到最长的那个作为标准名称
        standard_name = max(related_cities, key=len)
        
        # 将所有相关城市名映射到这个标准名称
        for related_city in related_cities:
            # 只有当当前映射比已有的更长时才更新，以防被短名称覆盖
            if related_city not in standard_map or len(standard_name) > len(standard_map[related_city]):
                standard_map[related_city] = standard_name
                
    # 补充用户提供的特殊映射，确保它们被优先考虑
    # 注意：用户提供的映射可能与启发式规则冲突，这里以用户为准
    user_overrides = {
        '厦门': '厦门市',
        '安康': '安康市',
        '阿克苏': '阿克苏地区',
        '大理': '大理白族自治州',
        '阿拉善': '阿拉善盟',
    }
    standard_map.update(user_overrides)
    
    # 最终应用映射
    df['市'] = df['市'].astype(str).str.strip().map(lambda x: standard_map.get(x, x))
    
    return df

df = smart_standardize_city_name(df.copy()) # 使用copy避免SettingWithCopyWarning

# 6. 输出清洗后的CSV文件
df.to_csv(output_path, index=False, encoding='utf-8-sig')

print(f"数据清洗完成。清洗后的文件已保存至: {output_path}")