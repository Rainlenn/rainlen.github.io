import pandas as pd
from sklearn.ensemble import RandomForestRegressor
import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif'] = ['Songti SC']
plt.rcParams['axes.unicode_minus'] = False
df = pd.read_csv('/Users/zhengruinan/Desktop/processed_table.csv')
df = df.sample(n=1000000, random_state=42)

target = 'num'
features = ['prise', 'month', 'displacement', 'province', 'fuel', 'transmission', 'body_type']
df_encoded = pd.get_dummies(df[features])
X = df_encoded
y = df[target]

model = RandomForestRegressor(n_estimators=100, max_depth=None, random_state=42, n_jobs=-1)
model.fit(X, y)

importance = pd.Series(model.feature_importances_, index=X.columns)
merged_importance = {
    '价格(prise)': importance.get('prise', 0),
    '月份(month)': importance.get('month', 0),
    '排量(displacement)': importance.get('displacement', 0),
    '省份(province)': importance[importance.index.str.startswith('province_')].sum(),
    '燃料类型(fuel)': importance[importance.index.str.startswith('fuel_')].sum(),
    '变速器(transmission)': importance[importance.index.str.startswith('transmission_')].sum(),
    '车身类型(body_type)': importance[importance.index.str.startswith('body_type_')].sum()
}

plt.figure(figsize=(8, 8))
plt.pie(merged_importance.values(), labels=merged_importance.keys(),
        autopct='%1.1f%%', startangle=140, colors=plt.cm.Set3.colors)
plt.title('How vital they are？', fontsize=16)

# 保存饼图图片
img_path = '/Users/zhengruinan/Desktop/importance_pie_chart.png'
plt.savefig(img_path)
plt.show()

importance_df = pd.DataFrame({
    'Indicator': list(merged_importance.keys()),
    'Importance': list(merged_importance.values())
})
excel_path = '/Users/zhengruinan/Desktop/importance_pie_data.xlsx'
importance_df.to_excel(excel_path, index=False)


print("好烦。。")
