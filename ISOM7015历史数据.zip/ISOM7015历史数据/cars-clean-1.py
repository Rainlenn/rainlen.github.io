import pandas as pd
import re
# 读取文件
cars_df = pd.read_csv('/Users/zhengruinan/Desktop/下次去香榭丽/4在cars和auto中过滤款型、字段标准化/cars.csv')
unique_df = pd.read_excel('/Users/zhengruinan/Desktop/下次去香榭丽/3提取sales唯一值/unique-ori.xlsx', sheet_name='Sheet1', engine='openpyxl')

# 步骤 1: 删除 W 列（版本年份-dict）为 "2023款" 或 "2024款" 的行
cars_df = cars_df[~cars_df['版本年份-dict'].isin(['2023款', '2024款'])]

# 步骤 2: 将 W 列（版本年份-dict）的值追加到 Y 列（唯一标识ID）中
cars_df['唯一标识ID'] = cars_df['唯一标识ID'].astype(str) + ' ' + cars_df['版本年份-dict'].astype(str)

# 定义一个函数：删除括号及括号内的内容
def remove_parentheses(text):
    if pd.isna(text):
        return text
    return re.sub(r'\(.*?\)', '', str(text)).strip()

# 对两边的车辆型号列进行处理
cars_df['车辆型号'] = cars_df['车辆型号'].apply(remove_parentheses)
unique_df['车辆型号'] = unique_df['车辆型号'].apply(remove_parentheses)

# 步骤 3: 检查 F 列（车辆型号）是否存在于 unique-ori.xlsx 的 E 列（车辆型号）中
valid_models = set(unique_df['车辆型号'].dropna())
cars_df = cars_df[cars_df['车辆型号'].isin(valid_models)]

# 输出处理后的数据到新文件
output_file = '/Users/zhengruinan/Desktop/下次去香榭丽/6根据型号和年份剔除cars无效行/cars_T1.csv'
cars_df.to_csv(output_file, index=False)

print(f"处理完成，结果已保存到 {output_file} 文件。剩余行数: {len(cars_df)}")