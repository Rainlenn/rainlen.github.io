import pandas as pd  # 导入 pandas 库，用于数据处理
from tqdm import tqdm  # 导入 tqdm 库，用于显示进度条

def clean_text(x):  # 定义一个函数，用于清洗文本（去除空格并转为小写）
    """清洗文本：去除空格并转为小写"""
    if isinstance(x, str):  # 如果 x 是字符串类型
        return x.strip().replace(" ", "").lower()  # 去除首尾空格，删除中间空格，并转换为小写
    return ""  # 如果不是字符串，返回空字符串

def match_score(base, target):  # 定义一个函数，用于计算两个字符串的匹配度
    """计算匹配度"""
    if not base or not target:  # 如果任一字符串为空，返回匹配度为 0
        return 0
    hit_chars = sum(1 for c in target if c in base)  # 统计 target 中有多少字符出现在 base 中
    score = hit_chars / len(base)  # 匹配度 = 命中字符数 / base 的长度
    return score  # 返回匹配度

def load_data(cars_path, autohome_path):  # 定义函数，用于加载两个 CSV 数据文件
    """加载数据文件"""
    try:
        cars = pd.read_csv(cars_path)  # 读取 cars 数据文件
        autohome = pd.read_csv(autohome_path)  # 读取 autohome 数据文件
        return cars, autohome  # 返回两个数据表
    except Exception as e:  # 如果读取过程中出错
        print(f"❌ 读取文件时出错：{e}")  # 打印错误信息
        raise  # 抛出异常，终止程序

def preprocess_data(cars, autohome):  # 定义函数，用于清洗两个数据表中的关键列
    """清洗数据"""
    try:
        cars['车型'] = cars['车型'].apply(clean_text)  # 对 cars 表中的“车型”列进行清洗
        autohome['车系名称'] = autohome['车系名称'].apply(clean_text)  # 对 autohome 表中的“车系名称”列进行清洗
        return cars, autohome  # 返回清洗后的数据表
    except Exception as e:  # 如果清洗过程中出错
        print(f"❌ 数据清洗出错：{e}")  # 打印错误信息
        raise  # 抛出异常，终止程序

def match_models(cars, autohome, threshold=0.35):  # 定义函数，用于匹配车型
    """匹配车型"""
    try:
        unique_models = cars['车型'].dropna().unique().tolist()  # 获取 cars 表中不为空的唯一车型列表
        best_models = []  # 初始化一个列表，用于存储最佳匹配结果

        # 使用 tqdm 显示匹配进度条
        for base in tqdm(autohome['车系名称'], desc="🚗 正在匹配车型"):  # 遍历 autohome 表中的每个车系名称
            best_match = None  # 初始化最佳匹配为空
            best_score = 0  # 初始化最高匹配度为 0

            for target in unique_models:  # 遍历所有唯一车型
                score = match_score(base, target)  # 计算当前 base 与 target 的匹配度
                if score > best_score:  # 如果当前匹配度更高
                    best_score = score  # 更新最高匹配度
                    best_match = target  # 更新最佳匹配车型

            if best_score >= threshold:  # 如果匹配度大于等于设定的阈值
                best_models.append(best_match)  # 添加最佳匹配车型
            else:
                best_models.append(None)  # 否则添加 None，表示无匹配结果

        autohome['车型'] = best_models  # 将匹配结果添加为 autohome 表中的新列“车型”
        return autohome  # 返回更新后的 autohome 表
    except Exception as e:  # 如果匹配过程中出错
        print(f"❌ 匹配过程中出错：{e}")  # 打印错误信息
        raise  # 抛出异常，终止程序

def save_results(autohome, output_path):  # 定义函数，用于保存结果到 CSV 文件
    """保存结果到 CSV 文件"""
    try:
        autohome.to_csv(output_path, index=False, encoding='utf-8-sig')  # 保存为 CSV 文件，不包含索引，使用 UTF-8 编码
        print(f"✅ 匹配完成！新文件已保存为：{output_path}")  # 打印保存成功提示
    except Exception as e:  # 如果保存过程中出错
        print(f"❌ 保存文件时出错：{e}")  # 打印错误信息
        raise  # 抛出异常，终止程序

def main():  # 主函数，控制整个流程
    # 文件路径
    cars_path = "/Users/zhengruinan/Desktop/cars to match.csv"  # cars 数据文件路径
    autohome_path = "/Users/zhengruinan/Desktop/autohome merged for matching.csv"  # autohome 数据文件路径
    output_path = "/Users/zhengruinan/Desktop/wjk.csv"  # 输出文件路径

    try:
        # 步骤 1：读取数据
        cars, autohome = load_data(cars_path, autohome_path)  # 调用函数读取数据

        # 步骤 2：清洗数据
        cars, autohome = preprocess_data(cars, autohome)  # 调用函数清洗数据

        # 步骤 3-5：匹配车型
        autohome = match_models(cars, autohome)  # 调用函数进行车型匹配

        # 步骤 6：保存结果
        save_results(autohome, output_path)  # 调用函数保存结果

        # 打印前 20 行结果
        print("\n📋 匹配结果预览（前 20 行）：")  # 打印提示信息
        print(autohome[['车系名称', '车型']].head(20))  # 打印前 20 行的匹配结果

    except Exception as e:  # 捕获整个流程中的异常
        print("⚠️ 程序运行过程中发生错误，请检查上方错误信息。")  # 打印通用错误提示

if __name__ == "__main__":  # 判断是否为主程序入口
    main()  # 执行主函数