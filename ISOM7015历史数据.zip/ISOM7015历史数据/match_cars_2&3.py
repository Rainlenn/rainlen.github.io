import pandas as pd
import re
from fuzzywuzzy import fuzz
import time

# --- 1. 定义文件路径和匹配阈值 ---
FILE_CARS_TO_MATCH = "/home/ubuntu/upload/carstomatch.csv"
FILE_AUTOHOME = "/home/ubuntu/upload/autohomemergedformatching.csv"
OUTPUT_FILE = "matched_car_data.xlsx"
FUZZY_THRESHOLD_SERIES = 70
FUZZY_THRESHOLD_MODEL = 70

# --- 2. 数据清洗和预处理函数 ---

def extract_year(model_name):
    """从款型名称中提取年份，例如 '2018款 2.0T' -> '2018款'"""
    model_name = str(model_name)
    # 匹配 'XXXX款' 格式
    match = re.search(r'(\d{4}款)', model_name)
    if match:
        return match.group(1)
    # 匹配 'XXXX年' 格式，虽然用户要求是'款型'中的年份，但为了鲁棒性可以考虑
    # match = re.search(r'(\d{4}年)', model_name)
    # if match:
    #     return match.group(1).replace('年', '款')
    return None

def normalize_fuel_type(fuel):
    """规范化燃料/能源类型"""
    fuel = str(fuel).lower().strip()
    if '汽油' in fuel:
        return '汽油'
    elif '柴油' in fuel:
        return '柴油'
    elif '纯电动' in fuel or '电动' in fuel:
        return '纯电动'
    elif '插电式混合动力' in fuel or '插混' in fuel:
        return '插电式混合动力'
    elif '油电混合' in fuel or '混合动力' in fuel:
        # 区分插电式和非插电式，这里统一为混合动力，如果需要更细致的区分，需要更多信息
        if '插电' in fuel:
            return '插电式混合动力'
        return '油电混合动力'
    elif '甲醇' in fuel:
        return '甲醇'
    return fuel

# --- 3. 匹配逻辑函数 ---

def find_best_match_optimized(row, autohome_lookup):
    """
    对 carstomatch 的每一行，在 autohome_lookup 中寻找最佳匹配项。
    autohome_lookup 是一个字典，键是 (normalized_fuel, extracted_year)
    """
    year_source = row['extracted_year']
    fuel_source = row['normalized_fuel']
    car_series_source = row['车型']
    model_source = row['款型']

    # 步骤 1: 通过精确匹配的复合键快速定位候选集
    key = (fuel_source, year_source)
    if key not in autohome_lookup:
        return None, None, None, None, 0, 0

    candidate_df = autohome_lookup[key]

    # 步骤 2: 对候选集进行车系名称模糊匹配 (fuzz.ratio)
    # 这一步是预筛选，以减少后续最复杂的款型模糊匹配的计算量
    candidate_df['series_match_score'] = candidate_df['车系名称'].apply(
        lambda x: fuzz.ratio(car_series_source, x)
    )

    # 进一步筛选出车系名称匹配度达到阈值的记录
    candidate_df = candidate_df[candidate_df['series_match_score'] >= FUZZY_THRESHOLD_SERIES].copy()

    if candidate_df.empty:
        return None, None, None, None, 0, 0

    # 步骤 3: 对满足前三个条件的记录进行款型名称模糊匹配 (Token Sort Ratio)
    candidate_df['model_match_score'] = candidate_df['车型名称'].apply(
        lambda x: fuzz.token_sort_ratio(model_source, x)
    )

    # 找到款型匹配度最高的记录
    best_match_row = candidate_df.loc[candidate_df['model_match_score'].idxmax()]
    best_model_score = best_match_row['model_match_score']
    best_series_score = best_match_row['series_match_score']

    if best_model_score >= FUZZY_THRESHOLD_MODEL:
        # 匹配成功，返回所需信息
        return (
            best_match_row['车型名称'],
            best_match_row['年份'],
            best_match_row['能源类型'],
            best_match_row['厂商指导价(元)'],
            best_model_score,
            best_series_score
        )
    else:
        # 款型模糊匹配未达到阈值
        return None, None, None, None, best_model_score, best_series_score

# --- 4. 主执行逻辑 ---

def main():
    start_time = time.time()
    print("开始加载数据...")
    
    # 加载数据
    try:
        # 尝试使用 utf-8 编码，如果失败则尝试 gbk
        autohome_df = pd.read_csv(FILE_AUTOHOME, encoding='utf-8', low_memory=False)
        if autohome_df.shape[1] == 1:
             autohome_df = pd.read_csv(FILE_AUTOHOME, encoding='gbk', low_memory=False)
    except Exception as e:
        print(f"加载 autohome_df 失败: {e}")
        return

    try:
        carstomatch_df = pd.read_csv(FILE_CARS_TO_MATCH, encoding='utf-8', low_memory=False)
        if carstomatch_df.shape[1] == 1:
             carstomatch_df = pd.read_csv(FILE_CARS_TO_MATCH, encoding='gbk', low_memory=False)
    except Exception as e:
        print(f"加载 carstomatch_df 失败: {e}")
        return

    print(f"autohome_df 记录数: {len(autohome_df)}")
    print(f"carstomatch_df 记录数: {len(carstomatch_df)}")

    # 检查关键列是否存在
    required_autohome_cols = ['车系名称', '年份', '能源类型', '车型名称', '厂商指导价(元)']
    required_carstomatch_cols = ['车型', '款型', '燃料']

    if not all(col in autohome_df.columns for col in required_autohome_cols):
        print(f"autohome_df 缺少关键列: {required_autohome_cols}")
        print(f"autohome_df 列名: {autohome_df.columns.tolist()}")
        return

    if not all(col in carstomatch_df.columns for col in required_carstomatch_cols):
        print(f"carstomatch_df 缺少关键列: {required_carstomatch_cols}")
        print(f"carstomatch_df 列名: {carstomatch_df.columns.tolist()}")
        return

    print("开始数据预处理...")

    # --- autohome_df 预处理 ---
    # 规范化能源类型
    autohome_df['normalized_fuel'] = autohome_df['能源类型'].apply(normalize_fuel_type)
    # 规范化年份格式，确保与 carstomatch_df 提取的格式一致 (e.g., '2015款')
    autohome_df['年份'] = autohome_df['年份'].astype(str).str.replace('款', '款', regex=False)
    
    # 创建 autohome_df 的查找字典，键为 (normalized_fuel, 年份)
    # 这一步是性能优化的关键，将 O(N*M) 的查找复杂度降低
    autohome_lookup = autohome_df.groupby(['normalized_fuel', '年份'])
    autohome_lookup_dict = {name: group.reset_index(drop=True) for name, group in autohome_lookup}
    print(f"autohome_df 查找字典创建完成，包含 {len(autohome_lookup_dict)} 个键。")

    # --- carstomatch_df 预处理 ---
    carstomatch_df['extracted_year'] = carstomatch_df['款型'].apply(extract_year)
    carstomatch_df['normalized_fuel'] = carstomatch_df['燃料'].apply(normalize_fuel_type)

    # 过滤掉无法提取年份的记录
    initial_count = len(carstomatch_df)
    carstomatch_df_filtered = carstomatch_df.dropna(subset=['extracted_year']).copy()
    print(f"carstomatch_df 过滤掉无法提取年份的记录: {initial_count - len(carstomatch_df_filtered)} 条")
    print(f"剩余待匹配记录数: {len(carstomatch_df_filtered)}")

    # 匹配核心逻辑
    print("开始执行匹配逻辑...")

    # 遍历 carstomatch_df_filtered 进行匹配
    # 使用 apply 配合查找字典，避免在 apply 内部对整个 autohome_df 进行筛选
    results = carstomatch_df_filtered.apply(
        lambda row: find_best_match_optimized(row, autohome_lookup_dict),
        axis=1,
        result_type='expand'
    )

    # 将匹配结果赋值给 DataFrame
    carstomatch_df_filtered[['matched_车型名称', 'matched_年份', 'matched_能源类型', '厂商指导价(元)', '款型模糊匹配得分', '车系模糊匹配得分']] = results

    # 统计匹配结果
    matched_count = carstomatch_df_filtered['厂商指导价(元)'].notna().sum()
    end_time = time.time()
    print(f"匹配完成。总记录数: {len(carstomatch_df_filtered)}, 成功匹配数: {matched_count}")
    print(f"总耗时: {end_time - start_time:.2f} 秒")

    # 准备最终输出
    # 原始数据 + 匹配结果
    final_output_df = carstomatch_df_filtered.drop(columns=['extracted_year', 'normalized_fuel'])

    # 重新组织列的顺序，将匹配结果放在一起
    output_cols = carstomatch_df.columns.tolist() + [
        'matched_车型名称',
        'matched_年份',
        'matched_能源类型',
        '厂商指导价(元)',
        '款型模糊匹配得分',
        '车系模糊匹配得分'
    ]
    # 确保列存在，防止因 drop 导致的 KeyError
    final_output_df = final_output_df.reindex(columns=output_cols, fill_value=None)

    # 导出到 Excel
    try:
        final_output_df.to_excel(OUTPUT_FILE, index=False)
        print(f"结果已成功保存到 {OUTPUT_FILE}")
    except Exception as e:
        print(f"保存 Excel 文件失败: {e}")

if __name__ == "__main__":
    main()
