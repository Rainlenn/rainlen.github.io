import pandas as pd
from tqdm import tqdm
import re

# ==============================
# 1. 配置与常量
# ==============================
FILE1 = "/Users/zhengruinan/Desktop/cars to match.csv"
FILE2 = "/Users/zhengruinan/Desktop/autohome merged for matching.csv"

skip_cols = ["Unnamed: 0", "car_index", "首字母", "品牌ID", "厂商ID", "车系ID", "车型ID", "厂商指导价(元)", "级别", "车身结构", "变速箱"]

fuel_map = {
    "cng": "CNG",
    "汽油/cng": "汽油/CNG",
    "汽油": "汽油",
    "柴油": "柴油",
    "甲醇": "甲醇",
    "纯电动": "纯电动",
    "插电式混合": "插电式混合动力",
    "油电混合": "油电混合动力",
    "增程式": "增程式混合动力"
}

# ==============================
# 2. 工具函数
# ==============================
def detect_column(df, candidates):
    """检测候选列是否存在"""
    for col in candidates:
        if col in df.columns:
            return col
    return None

def normalize_transmission(value):
    """提取变速器缩写"""
    match = re.search(r"[A-Z]+", str(value).upper())
    return match.group(0) if match else None

def extract_displacement(text):
    """提取排量格式：数字+小数点+数字+L或T"""
    match = re.search(r"\d+\.\d+[LT]", str(text).upper())
    return match.group(0).strip() if match else None

def clean_fuel(value):
    """标准化燃料类型"""
    if not value or str(value).strip() == "-":
        return None
    text = str(value).lower()
    if "汽油" in text and "cng" in text:
        return "汽油/CNG"
    text = re.split(r"[+/]", text)[0]
    for key in fuel_map.keys():
        if key in text:
            return fuel_map[key]
    return None

def clean_text(value, replace_dash_with_space=False):
    """清理文本：NaN或'-'返回空；横杠处理"""
    if not value or str(value).lower() == "nan" or str(value).strip() == "-":
        return ""
    text = str(value).strip()
    if replace_dash_with_space:
        text = text.replace("-", " ")  # 横杠替换为空格
    else:
        text = text.replace("-", "")  # 删除横杠
    return text

# ==============================
# 3. 生成 mix3 列逻辑
# ==============================
def generate_mix3(row):
    """根据规则生成 mix3 列"""
    factory = clean_text(row.get("厂商名称", row.get("企业", "")), replace_dash_with_space=False)
    brand = clean_text(row.get("品牌名称", row.get("品牌", "")), replace_dash_with_space=True)
    series = clean_text(row.get("车系名称", row.get("车型", "")), replace_dash_with_space=True)

    parts = []
    if factory and brand and factory == brand:
        parts.append(brand)
    else:
        if factory and factory not in series and factory not in brand:
            parts.append(factory)
        if brand and brand not in series and brand not in factory:
            parts.append(brand)
    if series:
        parts.append(series)

    unique_parts = []
    for p in parts:
        if p not in unique_parts:
            unique_parts.append(p)

    mix3 = " ".join(unique_parts).strip()

    for keyword in [factory, brand]:
        if keyword and mix3.count(keyword) > 1:
            first_index = mix3.find(keyword)
            before = mix3[:first_index + len(keyword)]
            after = mix3[first_index + len(keyword):]
            after = after.replace(keyword, "")
            mix3 = before + after

    return " ".join(mix3.split())

# ==============================
# 4. 文本清理函数
# ==============================
def remove_priority_text(remaining_text, df, idx):
    """删除优先字段，避免重复"""
    for i in range(1, 7):
        df.at[idx, f"辅助列{i}"] = ""

    for col in ["车系名称-dict", "车型-dict"]:
        if col in df.columns and pd.notna(df.at[idx, col]):
            val = str(df.at[idx, col]).strip()
            val = re.sub(r"\u3000", " ", val)
            parts = re.findall(r"[\u4e00-\u9fa5]+|[A-Za-z0-9\.\·\!\:\#\-]+|[\(\)（）]", val)
            for i in range(min(len(parts), 6)):
                df.at[idx, f"辅助列{i+1}"] = parts[i]

    for i in range(1, 7):
        block = str(df.at[idx, f"辅助列{i}"]).strip()
        if block and block in remaining_text:
            remaining_text = remaining_text.replace(block, "", 1)

    for priority_col in ["车系名称-dict", "车型-dict", "品牌-dict", "品牌名称-dict", "版本年份-dict", "年份-dict"]:
        if priority_col in df.columns and pd.notna(df.at[idx, priority_col]):
            val = str(df.at[idx, priority_col]).strip()
            pattern = re.sub(r"\s+", r"\\s*", re.escape(val))
            remaining_text = re.sub(pattern, "", remaining_text, flags=re.IGNORECASE)

            if priority_col in ["车型-dict", "车系名称-dict"]:
                short_pattern = re.findall(r"\d+[A-Z]+", val.upper())
                for sp in short_pattern:
                    remaining_text = re.sub(re.escape(sp), "", remaining_text, flags=re.IGNORECASE)
                num_pattern = re.findall(r"\b\d+\b", val)
                for np in num_pattern:
                    remaining_text = re.sub(re.escape(np), "", remaining_text, flags=re.IGNORECASE)

    return remaining_text

def clean_remaining_text(text):
    """清理剩余文本，去掉重复词"""
    text = re.sub(r"\s+", " ", text).strip()
    text = " ".join(dict.fromkeys(text.split()))
    return "" if text.lower() == "nan" or text == "" else text

# ==============================
# 5. 核心处理逻辑
# ==============================
def process_row(df, idx, mixed_col):
    """处理每一行，提取字段并清理剩余文本"""
    text = str(df.loc[idx, mixed_col])
    text_upper = text.upper()
    remaining_text = text

    # 提取年份
    year_match = re.search(r"(\d{4})款", text)
    if year_match:
        df.at[idx, "版本年份-dict"] = f"{year_match.group(1)}款"

    for col in df.columns:
        if col == mixed_col or col.endswith("-dict") or col in skip_cols or col in ["版本年份-dict", "剩余文本", "mix3"]:
            continue
        value = str(df.loc[idx, col])
        if pd.notna(value):
            if col == "排量(L)":
                disp = extract_displacement(text)
                # 如果正则没匹配到，用原始排量字段（验证格式）
                if not disp and re.match(r"\d+\.\d+[LT]", value.upper()):
                    disp = value.upper()
                df.at[idx, f"{col}-dict"] = disp if disp else ""
                if disp:
                    remaining_text = re.sub(re.escape(disp), "", remaining_text, flags=re.IGNORECASE)
                continue

            if re.search(re.escape(value.strip()), text, flags=re.IGNORECASE):
                df.at[idx, f"{col}-dict"] = value
                remaining_text = re.sub(re.escape(value.strip()), "", remaining_text, flags=re.IGNORECASE)

            elif col == "变速器":
                norm_value = normalize_transmission(value)
                if norm_value and norm_value in text_upper:
                    df.at[idx, f"{col}-dict"] = value
                    remaining_text = re.sub(re.escape(norm_value), "", remaining_text, flags=re.IGNORECASE)

            elif col in ["燃料", "能源类型"]:
                clean_val = clean_fuel(value)
                if clean_val and (clean_val.upper() in text_upper or value in text_upper):
                    df.at[idx, f"{col}-dict"] = value
                    remaining_text = re.sub(re.escape(value.strip()), "", remaining_text, flags=re.IGNORECASE)

    remaining_text = remove_priority_text(remaining_text, df, idx)
    df.at[idx, "剩余文本"] = clean_remaining_text(remaining_text)

# ==============================
# 6. 文件处理逻辑
# ==============================
def process_file(file_path, possible_cols, output_name):
    try:
        df = pd.read_csv(file_path, low_memory=False)
        print(f"✅ 成功读取文件: {file_path}, 行数: {len(df)}")

        # 补全缺失款型
        if "车辆型号" in df.columns and "款型" in df.columns:
            mapping = (
                df[df["款型"].notna()]
                .groupby("车辆型号")["款型"]
                .agg(lambda x: x.value_counts().index[0])
                .to_dict()
            )
            df["款型"] = df.apply(
                lambda row: mapping.get(row["车辆型号"], row["款型"]) if pd.isna(row["款型"]) else row["款型"],
                axis=1
            )

        # 清理横杠逻辑
        for col in ["厂商名称", "品牌名称", "车系名称", "款型", "车型名称"]:
            if col in df.columns:
                df[col] = df[col].apply(lambda x: clean_text(x, replace_dash_with_space=(col != "厂商名称")))

        # 年份处理
        if "年份" in df.columns:
            df["年份"] = df["年份"].apply(lambda x: str(x) + "款" if pd.notna(x) and "款" not in str(x) else x)

        mixed_col = detect_column(df, possible_cols)
        if mixed_col is None:
            raise ValueError(f"找不到混合字段列: {possible_cols}")

        # 生成 mix3
        df["mix3"] = df.apply(generate_mix3, axis=1)

        # 初始化 dict 列
        for col in df.columns:
            if col != mixed_col and col not in skip_cols and col != "mix3":
                df[f"{col}-dict"] = None
        df["版本年份-dict"] = None
        df["剩余文本"] = None
        for i in range(1, 7):
            df[f"辅助列{i}"] = ""

        # 行处理
        for idx in tqdm(df.index, desc=f"处理 {file_path}"):
            process_row(df, idx, mixed_col)

        # 删除辅助列
        cols_to_remove = [f"辅助列{i}" for i in range(1, 7)] + [f"辅助列{i}-dict" for i in range(1, 7)]
        for col in cols_to_remove:
            if col in df.columns:
                df.drop(columns=[col], inplace=True)

        df["唯一标识ID"] = df.apply(
            lambda row: " ".join([
                str(val) for val in [
                    row.get("mix3", ""),
                    row.get("年份", ""),
                    row.get("排量(L)", row.get("排量", "")),
                    row.get("剩余文本", ""),
                    row.get("燃料", row.get("能源类型", "")),
                    row.get("级别", ""),
                    row.get("车身结构", row.get("车身类型", "")),
                    row.get("变速箱", row.get("变速器", ""))
                ] if pd.notna(val) and str(val).strip() != ""  # ✅ 过滤 NaN 和空字符串
            ]),
            axis=1
        )

        # 保存文件
        df.to_csv(output_name, index=False, encoding="utf-8-sig")
        print(f"✅ 文件处理完成，结果保存为: {output_name}")
        return df

    except Exception as e:
        print(f"❌ 错误: {e}")
        return None

# 主程序入口
df1_result = process_file(FILE1, ["款型", "车型"], "/Users/zhengruinan/Desktop/cars_matched_expanded.csv")
df2_result = process_file(FILE2, ["车型名称"], "/Users/zhengruinan/Desktop/autohome_matched_expanded.csv")