"""
车辆型号和款型严格匹配脚本
功能：根据车辆型号和款型（同年款）严格匹配两个数据集，将"matched_2&3"中的厂商指导价和匹配得分添加到"sales data"中。
新增功能：在输出文件之前处理厂商指导价列，统一价格格式。
"""

import pandas as pd  # 导入pandas库用于数据处理
import re  # 导入正则表达式库用于文本解析
import numpy as np  # 导入numpy库用于数值计算
from tqdm import tqdm  # 导入tqdm库用于显示进度条

# 定义常量
MATCHED_FILE = '/Users/zhengruinan/Desktop/2and3.xlsx'  # 匹配文件路径
SALES_FILE = '/Users/zhengruinan/Desktop/sales data.csv'  # 销售数据文件路径
OUTPUT_FILE = '/Users/zhengruinan/Desktop/1and2and3.xlsx'  # 输出文件路径
CSV_OUTPUT_FILE = '/Users/zhengruinan/Desktop/1and2and3.csv'
# 处理厂商指导价列
def normalize_price_column(df, column_name):
    """
    处理厂商指导价列：
    1. 如果包含英文波浪号 (~)，格式如 '5.08万~5.21万'，取两数平均后乘以10000。
    2. 如果没有波浪号但以 '万' 结尾，如 '13.36万'，乘以10000。
    3. 否则保持原值。
    """
    normalized_prices = []
    for price in tqdm(df[column_name], desc="处理厂商指导价列"):
        if pd.isna(price):  # 如果为空，直接保留None
            normalized_prices.append(None)
            continue
        price_str = str(price).strip()
        # 规则1：包含英文波浪号
        if '~' in price_str:
            nums = re.findall(r'\d+\.?\d*', price_str)  # 提取两个数字
            if len(nums) == 2:
                avg_price = (float(nums[0]) + float(nums[1])) / 2 * 10000
                normalized_prices.append(avg_price)
            else:
                normalized_prices.append(price)  # 格式异常，保留原值
        # 规则2：以 '万' 结尾
        elif price_str.endswith('万'):
            num_match = re.match(r'(\d+\.?\d*)万', price_str)
            if num_match:
                normalized_prices.append(float(num_match.group(1)) * 10000)
            else:
                normalized_prices.append(price)
        else:
            normalized_prices.append(price)  # 保持原值
    df[column_name] = normalized_prices
    return df

def extract_keywords(text):  # 提取关键词
    if pd.isna(text):
        return {'year': None, 'keywords': set()}
    text = str(text)
    keywords = set()
    year = None
    year_pattern = r'(\d{4}款)'
    year_match = re.search(year_pattern, text)
    if year_match:
        year = year_match.group(1)
        keywords.add(year)
    version_pattern = r'[\u4e00-\u9fa5]+版'
    versions = re.findall(version_pattern, text)
    keywords.update(versions)
    power_pattern = r'\d+\.?\d*[TL]|TURBO|\d+TURBO'
    powers = re.findall(power_pattern, text)
    keywords.update(powers)
    drive_pattern = r'[两四]驱'
    drives = re.findall(drive_pattern, text)
    keywords.update(drives)
    return {'year': year, 'keywords': keywords}

def calculate_match_score(keywords1, keywords2):  # 计算匹配得分
    if not keywords1 or not keywords2:
        return 0.0
    versions1 = {k for k in keywords1 if k.endswith('版')}
    versions2 = {k for k in keywords2 if k.endswith('版')}
    version_match = len(versions1 & versions2)
    other_keywords1 = keywords1 - versions1
    other_keywords2 = keywords2 - versions2
    other_match = len(other_keywords1 & other_keywords2)
    score = version_match * 10.0 + other_match * 1.0
    return score

def match_vehicle_price_strict(matched_file_path, sales_file_path):
    print("=" * 60)
    print("车辆型号和款型严格匹配程序")
    print("=" * 60)

    # 1. 读取数据文件
    print("\n[步骤 1/5] 读取数据文件...")
    matched_df = pd.read_excel(matched_file_path)
    sales_df = pd.read_csv(sales_file_path)
    print(f" - matched_2&3.xlsx: {len(matched_df):,} 行")
    print(f" - salesdata.csv: {len(sales_df):,} 行")

    # 2. 提取关键词和年款
    print("\n[步骤 2/5] 提取款型关键词和年款...")
    matched_df['extracted'] = matched_df['款型'].apply(extract_keywords)
    sales_df['extracted'] = sales_df['款型'].apply(extract_keywords)
    matched_df['year'] = matched_df['extracted'].apply(lambda x: x['year'])
    matched_df['keywords'] = matched_df['extracted'].apply(lambda x: x['keywords'])
    sales_df['year'] = sales_df['extracted'].apply(lambda x: x['year'])
    sales_df['keywords'] = sales_df['extracted'].apply(lambda x: x['keywords'])
    matched_df = matched_df.drop('extracted', axis=1)
    sales_df = sales_df.drop('extracted', axis=1)
    print(" - 关键词和年款提取完成")

    # 3. 构建匹配字典
    print("\n[步骤 3/5] 构建匹配字典...")
    matched_dict = {}
    for idx, row in tqdm(matched_df.iterrows(), total=len(matched_df), desc='构建匹配字典'):
        vehicle_model = row['车辆型号']
        year = row['year']
        if pd.isna(vehicle_model) or year is None:
            continue
        key = (vehicle_model, year)
        if key not in matched_dict:
            matched_dict[key] = []
        matched_dict[key].append({
            'keywords': row['keywords'],
            'price': row['厂商指导价(元)'],
            'model_name': row['款型']
        })
    print(f" - 共有 {len(matched_dict):,} 个不同的 (车辆型号, 年款) 组合")

    # 4. 执行严格匹配
    print("\n[步骤 4/5] 执行严格匹配...")
    def find_best_match_strict(row):
        vehicle_model = row['车辆型号']
        year = row['year']
        sales_keywords = row['keywords']
        if year is None:
            return None, None
        key = (vehicle_model, year)
        if key not in matched_dict:
            return None, None
        candidates = matched_dict[key]
        best_score = -1.0
        best_price = None
        for candidate in candidates:
            if pd.isna(candidate['price']):
                continue
            score = calculate_match_score(sales_keywords, candidate['keywords'])
            if score > best_score:
                best_score = score
                best_price = candidate['price']
        if best_score > 0.0:
            return best_price, best_score
        return None, None

    results = sales_df.apply(find_best_match_strict, axis=1, result_type='expand')
    sales_df['厂商指导价(元)'] = results[0]
    sales_df['匹配评分规则得分'] = results[1]
    sales_df = sales_df.drop(['keywords', 'year'], axis=1)

    # 5. 统计匹配结果
    print("\n[步骤 5/5] 统计匹配结果...")
    matched_count = sales_df['厂商指导价(元)'].notna().sum()
    total_count = len(sales_df)
    match_rate = matched_count / total_count * 100
    print("\n" + "=" * 60)
    print("匹配统计")
    print("=" * 60)
    print(f"总记录数: {total_count:,}")
    print(f"成功匹配: {matched_count:,}")
    print(f"未匹配: {total_count - matched_count:,}")
    print(f"匹配率: {match_rate:.2f}%")
    print("=" * 60)

    stats = {
        'total_count': total_count,
        'matched_count': matched_count,
        'unmatched_count': total_count - matched_count,
        'match_rate': match_rate
    }
    return sales_df, stats

def save_to_excel(df, output_path):
    MAX_ROWS = 1048576
    if len(df) <= MAX_ROWS:
        df.to_excel(output_path, index=False)
        print(f" - 结果已保存到: {output_path}")
    else:
        print(f" - 数据行数 ({len(df):,}) 超过Excel单表限制 ({MAX_ROWS:,})，将分表保存。")
        writer = pd.ExcelWriter(output_path, engine='xlsxwriter')
        num_sheets = (len(df) + MAX_ROWS - 1) // MAX_ROWS
        for i in range(num_sheets):
            start = i * MAX_ROWS
            end = min((i + 1) * MAX_ROWS, len(df))
            sheet_name = f'Sheet{i+1}'
            df.iloc[start:end].to_excel(writer, sheet_name=sheet_name, index=False)
            print(f" - 保存 {sheet_name}: {start+1:,} - {end:,} 行")
        writer.close()
        print(f" - 结果已分表保存到: {output_path}")

if __name__ == "__main__":
    result_df, stats = match_vehicle_price_strict(MATCHED_FILE, SALES_FILE)
    #处理厂商指导价列
    result_df = normalize_price_column(result_df, '厂商指导价(元)')
    save_to_excel(result_df, OUTPUT_FILE)
    # 保存 CSV 文件
    result_df.to_csv(CSV_OUTPUT_FILE, index=False, encoding='utf-8-sig')
    print(f" - 结果已保存为 CSV 和 XLSX 文件: {CSV_OUTPUT_FILE}")