
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import skew

# 读取CSV文件
file_path = '/Users/zhengruinan/Desktop/周一商分基础/小组合并作业/10根据syj final修改的连贯代码/sales_data_1119.csv'
df = pd.read_csv(file_path)

# 提取价格列并清理数据
price_col = '厂商指导价(元)'
prices = df[price_col].dropna()
prices = prices[prices > 0]  # 去掉非正数
prices = prices[prices < 899999]  # 去掉异常大值

# 计算偏度
price_skewness = skew(prices)
if price_skewness > 0:
    skew_direction = '右偏（长尾在右侧）'
elif price_skewness < 0:
    skew_direction = '左偏（长尾在左侧）'
else:
    skew_direction = '近似对称'

# 设置字体
plt.rcParams['font.family'] = 'Songti SC'
plt.rcParams['axes.unicode_minus'] = False

# 绘制价格分布直方图 + KDE曲线
plt.figure(figsize=(10, 5))
sns.histplot(prices, bins=30, kde=True, color='#132020')

# 设置标题和标签
plt.title(f'Price Distribution and Skewness Analysis', fontsize=14)
plt.xlabel('Price', fontsize=12)
plt.ylabel('Counts', fontsize=12)

# 去掉四周边框
sns.despine(left=True, bottom=True)

# 添加淡淡的纵向网格线
plt.grid(axis='y', color='gray', linestyle='--', linewidth=0.5, alpha=0.3)

# 保存图表
plt.tight_layout()
plt.savefig('price_distribution_skewness.png', dpi=300)

# 输出偏度值和方向
print(f"价格偏度值: {price_skewness:.4f}, 分布方向: {skew_direction}")
