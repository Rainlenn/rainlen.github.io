import pandas as pd
from tqdm import tqdm
from joblib import Parallel, delayed
import time
from datetime import datetime
import traceback

# =========================
# 用户可修改的配置
# =========================
CARS_FILE = "/Users/suyujia/Desktop/new/cars_matched_expanded.csv"  # 输入文件1
AUTOHOME_FILE = "/Users/suyujia/Desktop/new/autohome_matched_expanded.csv"  # 输入文件2
OUTPUT_DIR = "/Users/suyujia/Desktop/new/"  # 输出目录
N_JOBS = -1  # 并行线程数（-1表示使用所有CPU核心）
THRESHOLD_HIT_RATE = 0.35  # 字符命中率阈值

# =========================
# 工具函数
# =========================
def simple_hit_rate(base, target):
    """集合交集版本：计算字符命中率"""
    base_set, target_set = set(base), set(target)
    return len(base_set & target_set) / len(base_set) if base_set else 0

# =========================
# 核心逻辑：命中率匹配
# =========================
try:
    print("📂 正在加载数据...")
    cars_df = pd.read_csv(CARS_FILE, low_memory=False)
    autohome_df = pd.read_csv(AUTOHOME_FILE, low_memory=False)

    # 去掉包含 '-dict' 的列
    cars_df = cars_df[[col for col in cars_df.columns if '-dict' not in col]]
    autohome_df = autohome_df[[col for col in autohome_df.columns if '-dict' not in col]]

    # 提取唯一标识ID列表
    if "唯一标识ID" not in cars_df.columns or "唯一标识ID" not in autohome_df.columns:
        raise ValueError("❌ 两个文件必须包含 '唯一标识ID' 列")

    cars_ids = cars_df["唯一标识ID"].dropna().astype(str).tolist()
    autohome_ids = autohome_df["唯一标识ID"].dropna().astype(str).tolist()

    print(f"✅ cars 唯一标识数量: {len(cars_ids)}")
    print(f"✅ autohome 唯一标识数量: {len(autohome_ids)}")

    # 命中率匹配
    print("🔍 开始字符命中率匹配...")
    start = time.time()

    def process_one(cid):
        best_score = max(simple_hit_rate(aid, cid) for aid in autohome_ids)
        return cid if best_score >= THRESHOLD_HIT_RATE else None

    matched_ids = Parallel(n_jobs=N_JOBS, backend="loky")(
        delayed(process_one)(cid) for cid in tqdm(cars_ids, desc="匹配进度", unit="项", dynamic_ncols=True)
    )

    matched_ids = [mid for mid in matched_ids if mid is not None]
    elapsed = time.time() - start
    speed = len(cars_ids) / elapsed
    print(f"✅ 匹配完成，共匹配到 {len(matched_ids)} 行，耗时 {elapsed:.2f} 秒，速度 {speed:.2f} 项/秒")

    # 合并完整行数据
    print("🔗 正在合并匹配数据...")
    merged_df = pd.merge(
        cars_df[cars_df["唯一标识ID"].isin(matched_ids)],
        autohome_df[autohome_df["唯一标识ID"].isin(matched_ids)],
        on="唯一标识ID",
        how="inner",
        suffixes=("_cars", "_autohome")
    )

    print(f"✅ 合并完成，最终输出行数: {len(merged_df)}")

    # 保存结果文件（带时间戳）
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = f"{OUTPUT_DIR}hit_rate_matched_{timestamp}.xlsx"
    merged_df.to_excel(output_file, index=False, engine="openpyxl")
    print(f"✅ 已保存结果到 {output_file}")

except Exception as e:
    print("❌ 程序运行出错:", e)
    print(traceback.format_exc())