import pandas as pd
import re
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from tqdm import tqdm

# ✅ 詢問使用者是否只跑前 1000 筆資料
test_mode = input("是否只先測試前 1000 筆資料？(y/n): ").strip().lower()
if test_mode == 'y':
    test_limit = 1000
else:
    test_limit = None

try:
    # 1. 讀取資料
    print("📂 正在讀取資料...")
    cars = pd.read_csv("/Users/zhengruinan/Desktop/cars to match.csv")
    autohome = pd.read_csv("/Users/zhengruinan/Desktop/autohome merged for matching.csv")
    print(f"✅ 成功讀取資料：cars({len(cars)}行)，autohome({len(autohome)}行)")
except Exception as e:
    print(f"❌ 讀取資料時發生錯誤：{e}")
    exit()

# ✅ 若是測試模式，只保留前 N 筆資料
if test_limit:
    cars = cars.iloc[:test_limit].copy()
    print(f"🔍 測試模式啟用：僅處理前 {test_limit} 筆資料")

# 2. 定義清洗 + 去重函數
def clean_and_deduplicate(text):
    """
    清洗文本並去重：
    - 轉小寫
    - 保留中文、字母、數字
    - 去掉標點符號
    - 去重但保留原始順序
    """
    if pd.isna(text):
        return ""
    text = str(text).lower()
    text = re.sub(r"[^\w\d\u4e00-\u9fff]", " ", text)  # 保留中文、字母、數字
    tokens = text.split()
    unique_tokens = list(dict.fromkeys(tokens))  # 去重但保留順序
    return " ".join(unique_tokens)

# 3. 合併關鍵欄位並清洗
print("🧹 正在清洗並合併欄位...")
cars_fields = ['品牌', '车型', '款型', '排量', '燃料', '变速器']
autohome_fields = ['品牌名称', '车系名称', '车型名称', '年份', '排量(L)', '能源类型', '变速箱']

try:
    cars['combined'] = cars[cars_fields].fillna('').agg(' '.join, axis=1).apply(clean_and_deduplicate)
    autohome['combined'] = autohome[autohome_fields].fillna('').agg(' '.join, axis=1).apply(clean_and_deduplicate)
    print("✅ 清洗完成")
except Exception as e:
    print(f"❌ 清洗過程出錯：{e}")
    exit()

# 4. TF-IDF 向量化
print("🔍 正在進行 TF-IDF 向量化...")
try:
    vectorizer = TfidfVectorizer()
    tfidf_matrix_autohome = vectorizer.fit_transform(autohome['combined'])
    tfidf_matrix_cars = vectorizer.transform(cars['combined'])
    print("✅ 向量化完成")
except Exception as e:
    print(f"❌ 向量化過程出錯：{e}")
    exit()

# 5. 計算相似度
print("📐 正在計算相似度...")
try:
    similarities = cosine_similarity(tfidf_matrix_cars, tfidf_matrix_autohome)
    print("✅ 相似度計算完成")
except Exception as e:
    print(f"❌ 相似度計算出錯：{e}")
    exit()

# 6. 找出每行最佳匹配（加入進度條）
print("🔍 正在尋找最佳匹配...")
best_match_indices = []
best_scores = []

for i in tqdm(range(similarities.shape[0]), desc="匹配進度"):
    try:
        best_idx = similarities[i].argmax()
        best_score = similarities[i][best_idx]
        best_match_indices.append(best_idx)
        best_scores.append(round(best_score, 2))  # 保留兩位小數
    except Exception as e:
        print(f"⚠️ 匹配錯誤：第 {i} 行，錯誤訊息：{e}")
        best_match_indices.append(None)
        best_scores.append(0.0)

# 7. 構建結果 DataFrame
print("📦 正在構建結果表...")
try:
    matched_autohome = autohome.iloc[best_match_indices].reset_index(drop=True)
    matched_autohome.columns = [f"匹配_{col}" for col in matched_autohome.columns]

    result = pd.concat([cars.reset_index(drop=True), matched_autohome], axis=1)
    result['match_score'] = best_scores
    result['match_success'] = result['match_score'].apply(lambda x: True if x >= 0.8 else False)
    print("✅ 結果表構建完成")
except Exception as e:
    print(f"❌ 構建結果表出錯：{e}")
    exit()

# 8. 儲存結果
output_path = "/Users/zhengruinan/Desktop/tfidf.csv"
try:
    result.to_csv(output_path, index=False, encoding='utf-8-sig')
    print(f"✅ 匹配結果已儲存至：{output_path}")
except Exception as e:
    print(f"❌ 儲存結果時發生錯誤：{e}")