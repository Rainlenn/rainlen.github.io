import pandas as pd  # 导入 pandas 用于数据处理
import re  # 正则表达式模块，用于提取年份
from fuzzywuzzy import fuzz  # 模糊匹配库，用于字符串相似度计算
# from rapidfuzz import fuzz
import numpy as np  # 数值计算库
import time  # 用于计算耗时
import Levenshtein  # Levenshtein 距离库，用于字符串编辑距离
from tqdm import tqdm  # 进度条库

print(Levenshtein.distance("kitten", "sitting"))  # 测试 Levenshtein 距离，输出 3

# 1. 定义文件路径和匹配阈值
FILE_CARS_TO_MATCH = "/Users/zhengruinan/Desktop/cars to match.csv"  # 待匹配文件路径
FILE_AUTOHOME = "/Users/zhengruinan/Desktop/autohome merged for matching.csv"  # Autohome 数据文件路径
OUTPUT_FILE = "/Users/zhengruinan/Desktop/2and3.csv"  # 输出文件路径
FUZZY_THRESHOLD_SERIES = 70  # 车系名称模糊匹配阈值
FUZZY_THRESHOLD_MODEL = 70  # 款型名称模糊匹配阈值

# 2. 数据清洗和预处理函数
def extract_year(model_name):  # 从款型名称中提取年份
    model_name = str(model_name)  # 转换为字符串
    match = re.search(r'(\d{4}款)', model_name)  # 匹配 "XXXX款" 格式
    if match:
        return match.group(1)  # 返回匹配到的年份
    return None  # 未匹配到返回 None

def normalize_fuel_type(fuel):  # 规范化燃料类型
    fuel = str(fuel).lower().strip()  # 转小写并去除空格
    if '汽油' in fuel:
        return '汽油'
    elif '柴油' in fuel:
        return '柴油'
    elif '纯电动' in fuel or '电动' in fuel:
        return '纯电动'
    elif '插电式混合动力' in fuel or '插混' in fuel:
        return '插电式混合动力'
    elif '油电混合' in fuel or '混合动力' in fuel:
        if '插电' in fuel:
            return '插电式混合动力'
        return '油电混合动力'
    elif '甲醇' in fuel:
        return '甲醇'
    return fuel  # 返回原始值

# 3. 匹配逻辑函数
def find_best_match_optimized(row, autohome_lookup):  # 在 autohome_lookup 中寻找最佳匹配
    year_source = row['extracted_year']  # 提取年份
    fuel_source = row['normalized_fuel']  # 提取燃料类型
    car_series_source = row['车型']  # 提取车系
    model_source = row['款型']  # 提取款型

    key = (fuel_source, year_source)  # 组合键 (燃料, 年份)
    if key not in autohome_lookup:  # 如果没有候选集
        return None, None, None, None, 0, 0

    candidate_df = autohome_lookup[key]  # 获取候选集

    candidate_df['series_match_score'] = candidate_df['车系名称'].apply(
        lambda x: fuzz.ratio(car_series_source, x)  # 计算车系名称相似度
    )

    candidate_df = candidate_df[candidate_df['series_match_score'] >= FUZZY_THRESHOLD_SERIES].copy()  # 筛选车系匹配度高的记录
    if candidate_df.empty:
        return None, None, None, None, 0, 0

    candidate_df['model_match_score'] = candidate_df['车型名称'].apply(
        lambda x: fuzz.token_sort_ratio(model_source, x)  # 计算款型名称相似度
    )

    best_match_row = candidate_df.loc[candidate_df['model_match_score'].idxmax()]  # 找到最佳匹配行
    best_model_score = best_match_row['model_match_score']  # 款型匹配得分
    best_series_score = best_match_row['series_match_score']  # 车系匹配得分

    if best_model_score >= FUZZY_THRESHOLD_MODEL:  # 如果款型匹配度达标
        return (
            best_match_row['车型名称'],
            best_match_row['年份'],
            best_match_row['能源类型'],
            best_match_row['厂商指导价(元)'],
            best_model_score,
            best_series_score
        )
    else:
        return None, None, None, None, best_model_score, best_series_score

# 4. 主执行逻辑
def main():
    start_time = time.time()  # 记录开始时间
    print("开始加载数据...")

    # 加载 Autohome 数据
    try:
        autohome_df = pd.read_csv(FILE_AUTOHOME, encoding='utf-8', low_memory=False)
        if autohome_df.shape[1] == 1:
            autohome_df = pd.read_csv(FILE_AUTOHOME, encoding='gbk', low_memory=False)
    except Exception as e:
        print(f"加载 autohome_df 失败: {e}")
        return

    # 加载待匹配数据
    try:
        carstomatch_df = pd.read_csv(FILE_CARS_TO_MATCH, encoding='utf-8', low_memory=False)
        if carstomatch_df.shape[1] == 1:
            carstomatch_df = pd.read_csv(FILE_CARS_TO_MATCH, encoding='gbk', low_memory=False)
    except Exception as e:
        print(f"加载 carstomatch_df 失败: {e}")
        return

    print(f"autohome_df 记录数: {len(autohome_df)}")
    print(f"carstomatch_df 记录数: {len(carstomatch_df)}")

    # 检查关键列是否存在
    required_autohome_cols = ['车系名称', '年份', '能源类型', '车型名称', '厂商指导价(元)']
    required_carstomatch_cols = ['车型', '款型', '燃料']

    if not all(col in autohome_df.columns for col in required_autohome_cols):
        print(f"autohome_df 缺少关键列: {required_autohome_cols}")
        return

    if not all(col in carstomatch_df.columns for col in required_carstomatch_cols):
        print(f"carstomatch_df 缺少关键列: {required_carstomatch_cols}")
        return

    print("开始数据预处理...")

    # Autohome 数据预处理
    autohome_df['normalized_fuel'] = autohome_df['能源类型'].apply(normalize_fuel_type)  # 规范化燃料类型
    autohome_df['年份'] = autohome_df['年份'].astype(str).str.replace('款', '款', regex=False)  # 确保年份格式一致

    autohome_lookup = autohome_df.groupby(['normalized_fuel', '年份'])  # 按燃料和年份分组
    autohome_lookup_dict = {name: group.reset_index(drop=True) for name, group in autohome_lookup}  # 创建查找字典
    print(f"autohome_df 查找字典创建完成，包含 {len(autohome_lookup_dict)} 个键。")

    # carstomatch 数据预处理
    carstomatch_df['extracted_year'] = carstomatch_df['款型'].apply(extract_year)  # 提取年份
    carstomatch_df['normalized_fuel'] = carstomatch_df['燃料'].apply(normalize_fuel_type)  # 规范化燃料类型

    initial_count = len(carstomatch_df)
    carstomatch_df_filtered = carstomatch_df.dropna(subset=['extracted_year']).copy()  # 删除无法提取年份的记录
    print(f"过滤掉无法提取年份的记录: {initial_count - len(carstomatch_df_filtered)} 条")
    print(f"剩余待匹配记录数: {len(carstomatch_df_filtered)}")

    # 使用 tqdm 显示进度条
    results = []
    for _, row in tqdm(carstomatch_df_filtered.iterrows(), total=len(carstomatch_df_filtered), desc="匹配进度"):
        results.append(find_best_match_optimized(row, autohome_lookup_dict))

    # 将结果转换为 DataFrame
    results_df = pd.DataFrame(results, columns=[
        'matched_车型名称', 'matched_年份', 'matched_能源类型', '厂商指导价(元)', '款型模糊匹配得分', '车系模糊匹配得分'
    ])
    carstomatch_df_filtered = pd.concat([carstomatch_df_filtered.reset_index(drop=True), results_df], axis=1)

    matched_count = carstomatch_df_filtered['厂商指导价(元)'].notna().sum()  # 统计匹配成功数量
    end_time = time.time()
    print(f"匹配完成。总记录数: {len(carstomatch_df_filtered)}, 成功匹配数: {matched_count}")
    print(f"总耗时: {end_time - start_time:.2f} 秒")

    # 输出结果到 Excel
    try:
        carstomatch_df_filtered.to_csv(OUTPUT_FILE, index=False, encoding="utf-8-sig")
        print(f"结果已成功保存到 CSV 文件: {OUTPUT_FILE}")
    except Exception as e:
        print(f"保存 Excel 文件失败: {e}")

if __name__ == "__main__":
    main()