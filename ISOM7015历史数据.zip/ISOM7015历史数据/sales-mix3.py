import pandas as pd
import re
from tqdm import tqdm  # 用于进度条

# ==============================
# 1. 清理文本工具函数
# ==============================
def clean_text(text, replace_dash_with_space=True):
    """清理文本，去掉多余空格和特殊字符"""
    if not text or pd.isna(text):
        return ""
    text = str(text).strip()
    if replace_dash_with_space:
        text = text.replace("-", " ")
    return " ".join(text.split())

# ==============================
# 2. mix3 生成规则
# ==============================
def generate_mix3(row):
    """根据规则生成 mix3 列"""
    factory = clean_text(row.get("厂商名称", row.get("企业", "")), replace_dash_with_space=False)
    brand   = clean_text(row.get("品牌名称", row.get("品牌", "")), replace_dash_with_space=True)
    series  = clean_text(row.get("车系名称", row.get("车型", "")), replace_dash_with_space=True)

    # 新增逻辑：如果品牌是企业的子串并且品牌是车型的子串 → 删除品牌，并在车型中剔除品牌
    remove_brand = False
    if brand and (brand in factory) and (brand in series):
        remove_brand = True
        series = series.replace(brand, "").strip()  # 删除车型中的品牌

    parts = []
    if factory and brand and factory == brand:
        parts.append(brand)
    else:
        if factory and factory not in (series or "") and factory not in (brand or ""):
            parts.append(factory)
        if brand and not remove_brand and brand not in (series or "") and brand not in (factory or ""):
            parts.append(brand)
    if series:
        parts.append(series)

    # 去重并保持顺序
    unique_parts = list(dict.fromkeys(parts))

    mix3 = " ".join(unique_parts).strip()

    # 去掉重复关键词（如果出现多次）
    for keyword in [factory, brand]:
        if keyword and mix3.count(keyword) > 1:
            mix3 = keyword + " " + mix3.replace(keyword, "", 1).strip()

    return " ".join(mix3.split())

# ==============================
# 3. 主处理逻辑
# ==============================
file_path = "/Users/zhengruinan/Desktop/sales_part2.csv"
df = pd.read_csv(file_path, encoding="utf-8-sig")

# 初始化新列
df["年份_sales"] = ""
df["排量_sales"] = ""
df["燃料_sales"] = ""
df["变速器_sales"] = ""
df["车身类型_sales"] = ""
df["剩余文本_sales"] = ""
df["mix3_sales"] = ""

# 遍历每一行，加入进度条
for i, row in tqdm(df.iterrows(), total=len(df), desc="Processing rows"):
    text = str(row["款型"]) if pd.notna(row["款型"]) else ""

    # ✅ 提取年份：匹配四位数字 + 可选“年” + “款”
    year_match = re.search(r"(\d{4})(?:年)?款", text)
    year = f"{year_match.group(1)}款" if year_match else ""
    df.at[i, "年份_sales"] = year

    # ✅ 提取排量、燃料、变速器、车身类型
    extracted_parts = []
    for col, new_col in zip(["排量", "燃料", "变速器", "车身类型"],
                            ["排量_sales", "燃料_sales", "变速器_sales", "车身类型_sales"]):
        value = str(row[col]) if pd.notna(row[col]) else ""
        if value and value in text:
            df.at[i, new_col] = value
            extracted_parts.append(value)

    # ✅ 剩余文本：剔除年份和已提取的部分
    remaining_text = text
    if year:
        remaining_text = remaining_text.replace(year, "")
    for part in extracted_parts:
        remaining_text = remaining_text.replace(part, "")
    df.at[i, "剩余文本_sales"] = remaining_text.strip()

    # ✅ 使用 mix3 规则生成唯一标识
    df.at[i, "mix3_sales"] = generate_mix3(row)

# 保存为 CSV 文件
output_file = "/Users/zhengruinan/Desktop/sales_part2_v1.csv"
df.to_csv(output_file, index=False, encoding="utf-8-sig")

print(f"✅ 处理完成，结果已保存为 CSV 文件：{output_file}")