import pandas as pd  # 导入 pandas 库，用于处理表格数据
import re  # 导入正则表达式库，用于提取数字
from tqdm import tqdm  # 导入 tqdm 库，用于显示进度条

# 1. 自动读取 CSV 文件，尝试不同编码
def read_csv_with_encoding(file_path):
    for encoding in ['utf-8', 'gbk', 'gb18030']:  # 循环尝试三种常见中文编码
        try:
            return pd.read_csv(file_path, encoding=encoding)  # 成功读取文件后返回 DataFrame
        except UnicodeDecodeError:  # 如果出现编码错误，继续尝试下一个编码
            continue
    raise ValueError("无法读取文件，请检查编码。")  # 如果全部失败，抛出错误提示

# 2. 清理并标准化价格列
def clean_and_normalize_price(df, column_name='厂商指导价(元)'):
    # 删除空值
    df[column_name] = df[column_name].replace([' ', ''], pd.NA)  # 将空格和空字符串替换为 NaN
    df.dropna(subset=[column_name], inplace=True)  # 删除价格列中 NaN 的行

    # 定义内部函数：解析价格字符串并转换为整数（单位：元）
    def parse_price(price):
        if not isinstance(price, str):  # 如果不是字符串，返回 None
            return None
        price = price.strip()  # 去掉前后空格
        nums = re.findall(r'\d+\.?\d*', price)  # 用正则提取所有数字（包括小数）
        if '~' in price and len(nums) == 2:  # 如果包含波浪号且提取到两个数字，说明是区间价格
            return int(round((float(nums[0]) + float(nums[1])) / 2 * 10000, 0))  # 取平均值并乘以 10000，保留整数
        elif price.endswith('万') and nums:  # 如果以“万”结尾且提取到数字，说明是单一价格
            return int(round(float(nums[0]) * 10000, 0))  # 数值乘以 10000，保留整数
        return None  # 如果不符合规则，返回 None

    # 使用列表推导式和 tqdm 显示进度条，批量处理价格列
    df[column_name] = [parse_price(p) for p in tqdm(df[column_name], desc="处理厂商指导价")]
    return df  # 返回处理后的 DataFrame

# 3. 标准化城市名称
def standardize_city_names(df, column_name='市'):
    # 手动映射字典，用于处理特殊简称
    city_mapping = {
        '厦门': '厦门市',
        '安康': '安康市',
        '阿克苏': '阿克苏地区',
        '大理': '大理白族自治州',
        '阿拉善': '阿拉善盟',
    }
    # 常见行政区划后缀
    suffixes = ['市', '地区', '自治州', '盟', '旗', '县', '区']
    # 特殊城市，不加“市”
    special_cities = ['北京', '上海', '天津', '重庆', '香港', '澳门']

    # 定义内部函数：标准化城市名称
    def normalize(city):
        if pd.isna(city):  # 如果是 NaN，直接返回
            return city
        city = str(city).strip()  # 去掉空格
        if city in city_mapping:  # 如果在手动映射中，返回映射值
            return city_mapping[city]
        # 如果没有常见后缀，且不是特殊城市，则补全“市”
        if not any(city.endswith(suffix) for suffix in suffixes) and city not in special_cities:
            return city + '市'
        return city  # 否则保持原样

    df[column_name] = df[column_name].map(normalize)  # 应用标准化函数
    return df  # 返回处理后的 DataFrame

# 4. 主程序
def main(file_path, output_path):
    df = read_csv_with_encoding(file_path)  # 读取文件
    df = clean_and_normalize_price(df)  # 清理并标准化价格列
    df = standardize_city_names(df)  # 标准化城市名称
    df.to_csv(output_path, index=False, encoding='utf-8-sig')  # 保存文件，utf-8-sig 兼容 Excel
    print(f"洗好了，文件放在{output_path}")  # 打印提示信息

# 调用主程序
file_path = '/Users/zhengruinan/Desktop/sales_data_with_price_strict.csv'  # 输入文件路径
output_path = '/Users/zhengruinan/Desktop/sales_data_1119.csv'  # 输出文件路径
main(file_path, output_path)  # 执行清洗流程