# -*- coding: utf-8 -*-
import pandas as pd
from tqdm import tqdm
import re

# ==============================
# 1. 配置与常量
# ==============================
FILE1 = "/Users/zhengruinan/Desktop/cars to match.csv"
FILE2 = "/Users/zhengruinan/Desktop/autohome merged for matching.csv"

skip_cols = [
    "Unnamed: 0", "car_index", "首字母", "品牌ID", "厂商ID", "车系ID", "车型ID",
    "厂商指导价(元)", "级别", "车身类型_标准", "变速器_标准", "燃料_标准"]

# ---------- 燃料标准化（目标字典 + 简单映射） ----------
FUEL_MAP = {
    "汽油": "汽油",
    "柴油": "柴油",
    "纯电动": "纯电动",
    "插电式混合动力": "插电式混合动力",
    "油电混合动力": "油电混合动力",
    "增程式混合动力": "增程式混合动力",
    "CNG": "CNG",
    "汽油/CNG": "汽油/CNG",
    "甲醇": "甲醇",

    # cars 变体
    "汽油混合动力": "油电混合动力",
    "汽油天然气": "汽油/CNG",
    "天然气": "CNG",
    "燃料电池": "纯电动",

    # auto 变体
    "汽油+48V轻混系统": "油电混合动力",
    "油电混合": "油电混合动力",
    "增程式": "增程式混合动力",
    "汽油+CNG": "汽油/CNG",
    "汽油电驱": "油电混合动力",
    "柴油+48V轻混系统": "油电混合动力",
    "氢燃料": "纯电动",
    "甲醇混动": "油电混合动力",
    "汽油+90V轻混系统": "油电混合动力",
    "汽油+24V轻混系统": "油电混合动力",
}

def clean_fuel(value):
    """根据映射字典统一燃料类型为目标表格的标准值（最简版）——返回标准值或 None，不覆盖原始列"""
    if not value or str(value).strip() == "-":
        return None
    text = str(value).strip()
    return FUEL_MAP.get(text, None)

# ---------- 变速器标准化（sales data 标准 + 你优化的映射） ----------
SALES_TRANSMISSIONS = {
    "7DCT","CVT","9AT","6AT","6DCT","8AT","1AT","5MT","6MT",
    "10AT","7AT","2AT","4AT","5DCT","9DCT","8DCT","5AMT","5AT"
}

TRANSMISSION_MAP = {
    # auto 表常见描述 → 标准值
    "8挡手自一体": "8AT",
    "7挡湿式双离合": "7DCT",
    "7挡干式双离合": "7DCT",
    "8挡湿式双离合": "8DCT",
    "6挡湿式双离合": "6DCT",
    "6挡干式双离合": "6DCT",
    "9挡湿式双离合": "9DCT",
    "6挡手自一体": "6AT",
    "9挡手自一体": "9AT",
    "10挡手自一体": "10AT",
    "8挡自动": "8AT",
    "6挡自动": "6AT",
    "10挡自动": "10AT",
    "7挡手自一体": "7AT",
    "4挡自动": "4AT",
    "4挡自动 ": "4AT",
    "5挡自动": "5AT",
    "5挡手自一体": "5AT",
    "5挡手动": "5MT",
    "6挡手动": "6MT",
    "7挡手动": "7MT",
    "4挡手动": "4MT",
    "电动车单速变速箱": "1AT",
    "CVT无级变速": "CVT",
    "E-CVT无级变速": "CVT",
    "CVT无级变速(模拟7挡)": "CVT",
    "CVT无级变速(模拟8挡)": "CVT",
    "CVT无级变速(模拟6挡)": "CVT",
    "CVT无级变速(模拟5挡)": "CVT",
    "CVT无级变速(模拟10挡)": "CVT",
    "CVT无级变速(模拟9挡)": "CVT",
    "CVT无级变速(模拟4挡)": "CVT",
    "CVT无级变速模拟7挡": "CVT",
    "E-CVT+自动变速箱（模拟10挡）": "CVT",
    "E-CVT+自动变速箱(模拟10挡)": "CVT",
    "DHT": "CVT",
    "2挡DHT": "2AT",
    "4挡DHT": "4AT",
    "1挡DHT": "1AT",
    "3挡DHT": "3AT",
    "6挡AMT": "5AMT",
    "5挡AMT": "5AMT",
    "7挡AMT": "5AMT",
    "AMT（组合10挡）": "5AMT",
    "6挡序列": "5AMT",
    "7挡序列": "5AMT",
    "6挡序列变速箱(AMT)": "5AMT",
    "5挡序列": "5AMT",
    "7挡ISR变速箱": "5AMT",
    "6挡三离合电驱变速器": "6DCT",
    "9速 多离合式变速箱": "9DCT",
    "3挡自动": "4AT",
    "2挡自动": "2AT",
    # 占位/未知
    "待查": None,
    "默认": None,
    "-": None,
    "0": None,
}

def normalize_transmission_to_sales(value):
    """如已是标准值则不变，否则按字典映射；占位返回 None（不覆盖原始列）"""
    if value is None:
        return None
    text = str(value).strip()
    if text in ["-", "0", "默认", "待查", ""]:
        return None
    if text in SALES_TRANSMISSIONS:
        return text
    return TRANSMISSION_MAP.get(text, None)

# ---------- 车身类型标准化（关键词 + 优先级规则，不用大字典） ----------
TARGET_BODY_TYPES = {"NB", "SUV", "HB", "SW", "MPV", "交叉型乘用车", "CP"}

def clean_body_type(value):
    """
    将 cars['车身类型'] / auto['车身结构'] 统一映射到 sales data 的目标类型：
    NB、SUV、HB、SW、MPV、交叉型乘用车、CP；无法归类的返回 None。
    优化点：
    - 支持识别“跨界”优先归交叉型乘用车
    - 区分 SUV/MPV/旅行车/掀背/三厢/跑车
    - 兼容 auto 的长描述（如 5门5座SUV、硬顶跑车）
    """
    if value is None:
        return None
    t = str(value).strip()
    if not t or t == "-":
        return None

    # 已是目标值，直接返回
    if t in TARGET_BODY_TYPES:
        return t

    u = t.upper()
    tn = re.sub(r"\s+", "", t)  # 去空白

    # cars 的几种直接写法
    if t in {"三厢", "三厢车"}:
        return "NB"
    if t in {"两厢", "两厢车"}:
        return "HB"
    if t in {"交叉型"}:
        return "交叉型乘用车"

    # 优先级：跨界 > SUV/MPV > SW > HB > NB > CP
    # 1) 跨界（无论 SUV/旅行/两厢）
    if "跨界" in tn:
        return "交叉型乘用车"

    # 2) SUV
    if "SUV" in u:
        return "SUV"

    # 3) MPV
    if "MPV" in u:
        return "MPV"

    # 4) 旅行车 / Wagon
    if ("旅行" in tn) or ("WAGON" in u) or ("SW" in u):
        return "SW"

    # 5) 掀背 / 两厢 / Hatchback
    if ("掀背" in tn) or ("两厢" in tn) or ("HATCH" in u) or ("HB" in u):
        return "HB"

    # 6) 三厢 / 轿车 / Sedan / Notchback
    if ("三厢" in tn) or ("轿车" in tn) or ("SEDAN" in u) or ("NB" in u):
        return "NB"

    # 7) 跑车 / 敞篷 / Coupe
    if ("跑车" in tn) or ("敞篷" in tn) or ("COUPE" in u):
        return "CP"

    # 明确不在目标体系的
    if any(k in tn for k in ("皮卡", "客车", "货车", "轻卡", "微卡", "轻客", "微面")):
        return None

    return None

# ==============================
# 2. 工具函数
# ==============================
def detect_column(df, candidates):
    """检测候选列是否存在"""
    for col in candidates:
        if col in df.columns:
            return col
    return None

def normalize_transmission(value):
    """提取变速器缩写（供 process_row 内部匹配用）"""
    match = re.search(r"[A-Z]+", str(value).upper())
    return match.group(0) if match else None

def extract_displacement(text):
    """提取排量格式：数字+小数点+数字+L或T"""
    match = re.search(r"\d+\.\d+[LT]", str(text).upper())
    return match.group(0).strip() if match else None

def clean_text(value, replace_dash_with_space=False):
    """清理文本：NaN或'-'返回空；横杠处理"""
    if not value or str(value).lower() == "nan" or str(value).strip() == "-":
        return ""
    text = str(value).strip()
    if replace_dash_with_space:
        text = text.replace("-", " ")  # 横杠替换为空格
    else:
        text = text.replace("-", "")   # 删除横杠
    return text

# ==============================
# 3. 生成 mix3 列逻辑
# ==============================
def generate_mix3(row):
    """根据规则生成 mix3 列"""
    factory = clean_text(row.get("厂商名称", row.get("企业", "")), replace_dash_with_space=False)
    brand   = clean_text(row.get("品牌名称", row.get("品牌", "")), replace_dash_with_space=True)
    series  = clean_text(row.get("车系名称", row.get("车型", "")), replace_dash_with_space=True)

    parts = []
    if factory and brand and factory == brand:
        parts.append(brand)
    else:
        if factory and factory not in series and factory not in brand:
            parts.append(factory)
        if brand and brand not in series and brand not in factory:
            parts.append(brand)
    if series:
        parts.append(series)

    unique_parts = []
    for p in parts:
        if p not in unique_parts:
            unique_parts.append(p)

    mix3 = " ".join(unique_parts).strip()

    for keyword in [factory, brand]:
        if keyword and mix3.count(keyword) > 1:
            first_index = mix3.find(keyword)
            before = mix3[:first_index + len(keyword)]
            after  = mix3[first_index + len(keyword):]
            after  = after.replace(keyword, "")
            mix3   = before + after

    return " ".join(mix3.split())

# ==============================
# 4. 文本清理函数
# ==============================
def remove_priority_text(remaining_text, df, idx):
    """删除优先字段，避免重复"""
    for i in range(1, 7):
        df.at[idx, f"辅助列{i}"] = ""

    for col in ["车系名称-dict", "车型-dict"]:
        if col in df.columns and pd.notna(df.at[idx, col]):
            val = str(df.at[idx, col]).strip()
            val = re.sub(r"\u3000", " ", val)
            parts = re.findall(
                r"[\u4e00-\u9fa5]+|[A-Za-z0-9\.\·\!\:\#\-]+|[\(\)（）]",
                val
            )
            for i in range(min(len(parts), 6)):
                df.at[idx, f"辅助列{i+1}"] = parts[i]

    for i in range(1, 7):
        block = str(df.at[idx, f"辅助列{i}"]).strip()
        if block and block in remaining_text:
            remaining_text = remaining_text.replace(block, "", 1)

    for priority_col in ["车系名称-dict", "车型-dict", "品牌-dict", "品牌名称-dict", "版本年份-dict", "年份-dict"]:
        if priority_col in df.columns and pd.notna(df.at[idx, priority_col]):
            val = str(df.at[idx, priority_col]).strip()
            pattern = re.sub(r"\s+", r"\\s*", re.escape(val))
            remaining_text = re.sub(pattern, "", remaining_text, flags=re.IGNORECASE)

            if priority_col in ["车型-dict", "车系名称-dict"]:
                short_pattern = re.findall(r"\d+[A-Z]+", val.upper())
                for sp in short_pattern:
                    remaining_text = re.sub(re.escape(sp), "", remaining_text, flags=re.IGNORECASE)
                num_pattern = re.findall(r"\b\d+\b", val)
                for np in num_pattern:
                    remaining_text = re.sub(re.escape(np), "", remaining_text, flags=re.IGNORECASE)

    return remaining_text

def clean_remaining_text(text):
    """清理剩余文本，去掉重复词"""
    text = re.sub(r"\s+", " ", text).strip()
    text = " ".join(dict.fromkeys(text.split()))
    return "" if text.lower() == "nan" or text == "" else text

# ==============================
# 5. 核心处理逻辑
# ==============================
def process_row(df, idx, mixed_col):
    """处理每一行，提取字段并清理剩余文本"""
    text = str(df.loc[idx, mixed_col])
    text_upper = text.upper()
    remaining_text = text

    # 提取年份
    year_match = re.search(r"(\d{4})款", text)
    if year_match:
        df.at[idx, "版本年份-dict"] = f"{year_match.group(1)}款"

    for col in df.columns:
        if col == mixed_col or col.endswith("-dict") or col in skip_cols or col in ["版本年份-dict", "剩余文本", "mix3"]:
            continue
        value = str(df.loc[idx, col])
        if pd.notna(value):
            if col == "排量(L)":
                disp = extract_displacement(text)
                # 如果正则没匹配到，用原始排量字段（验证格式）
                if not disp and re.match(r"\d+\.\d+[LT]", value.upper()):
                    disp = value.upper()
                df.at[idx, f"{col}-dict"] = disp if disp else ""
                if disp:
                    remaining_text = re.sub(re.escape(disp), "", remaining_text, flags=re.IGNORECASE)
                continue

            if re.search(re.escape(value.strip()), text, flags=re.IGNORECASE):
                df.at[idx, f"{col}-dict"] = value
                remaining_text = re.sub(re.escape(value.strip()), "", remaining_text, flags=re.IGNORECASE)

            elif col == "变速器":
                norm_value = normalize_transmission(value)  # 仅用于从文本抽取缩写
                if norm_value and norm_value in text_upper:
                    df.at[idx, f"{col}-dict"] = value
                    remaining_text = re.sub(re.escape(norm_value), "", remaining_text, flags=re.IGNORECASE)

            elif col in ["燃料", "能源类型"]:
                clean_val = clean_fuel(value)
                if clean_val:
                    df.at[idx, f"{col}-dict"] = clean_val
                    remaining_text = re.sub(re.escape(value.strip()), "", remaining_text, flags=re.IGNORECASE)

    remaining_text = remove_priority_text(remaining_text, df, idx)
    df.at[idx, "剩余文本"] = clean_remaining_text(remaining_text)

# ==============================
# 6. 文件处理逻辑
# ==============================
def process_file(file_path, possible_cols, output_name):
    try:
        df = pd.read_csv(file_path, low_memory=False)
        print(f"✅ 成功读取文件: {file_path}, 行数: {len(df)}")

        # ✅ 新增列：标准化燃料（不改原始列）
        if "燃料" in df.columns:
            df["燃料_标准"] = df["燃料"].apply(clean_fuel)
        elif "能源类型" in df.columns:
            df["燃料_标准"] = df["能源类型"].apply(clean_fuel)

        # ✅ 新增列：标准化变速器（不改原始列）
        if "变速器" in df.columns:
            df["变速器_标准"] = df["变速器"].apply(normalize_transmission_to_sales)
        elif "变速箱" in df.columns:
            df["变速器_标准"] = df["变速箱"].apply(normalize_transmission_to_sales)

        # ✅ 新增列：标准化车身类型（不改原始列）
        if "车身类型" in df.columns:
            df["车身类型_标准"] = df["车身类型"].apply(clean_body_type)
        elif "车身结构" in df.columns:
            df["车身类型_标准"] = df["车身结构"].apply(clean_body_type)

        # 补全缺失款型
        if "车辆型号" in df.columns and "款型" in df.columns:
            mapping = (
                df[df["款型"].notna()]
                .groupby("车辆型号")["款型"]
                .agg(lambda x: x.value_counts().index[0])
                .to_dict()
            )
            df["款型"] = df.apply(
                lambda row: mapping.get(row["车辆型号"], row["款型"]) if pd.isna(row["款型"]) else row["款型"],
                axis=1
            )

        # 如果存在排量(L)列，且值为数字且大于0，则在后面加上 'L'
        if "排量(L)" in df.columns:
            df["排量(L)"] = df["排量(L)"].apply(
                lambda x: str(x) + "L" if pd.notna(x) and str(x).replace(".", "").isdigit() and float(x) > 0 else x
            )

        # 清理横杠逻辑
        for col in ["厂商名称", "品牌名称", "车系名称", "款型", "车型名称"]:
            if col in df.columns:
                df[col] = df[col].apply(lambda x: clean_text(x, replace_dash_with_space=(col != "厂商名称")))

        # 年份处理
        if "年份" in df.columns:
            df["年份"] = df["年份"].apply(lambda x: str(x) + "款" if pd.notna(x) and "款" not in str(x) else x)

        mixed_col = detect_column(df, possible_cols)
        if mixed_col is None:
            raise ValueError(f"找不到混合字段列: {possible_cols}")

        # 生成 mix3
        df["mix3"] = df.apply(generate_mix3, axis=1)

        # 初始化 dict 列
        for col in df.columns:
            if col != mixed_col and col not in skip_cols and col != "mix3":
                df[f"{col}-dict"] = None
        df["版本年份-dict"] = None
        df["剩余文本"] = None
        for i in range(1, 7):
            df[f"辅助列{i}"] = ""

        # 行处理
        for idx in tqdm(df.index, desc=f"处理 {file_path}"):
            process_row(df, idx, mixed_col)

        # 删除辅助列
        cols_to_remove = [f"辅助列{i}" for i in range(1, 7)] + [f"辅助列{i}-dict" for i in range(1, 7)]
        for col in cols_to_remove:
            if col in df.columns:
                df.drop(columns=[col], inplace=True)

        # ✅ 唯一标识ID —— 使用“标准化列”
        df["唯一标识ID"] = df.apply(
            lambda row: " ".join([
                str(val).strip() for val in [
                    row.get("mix3", ""),
                    row.get("年份", ""),
                    row.get("排量(L)", row.get("排量", "")),
                    row.get("剩余文本", ""),
                    row.get("燃料_标准", ""),          # 燃料（标准）
                    row.get("车身类型_标准", ""),      # 车身类型（标准）
                    row.get("变速器_标准", ""),        # 变速器（标准）
                ] if pd.notna(val) and str(val).strip() not in ["", "-"]
            ]),
            axis=1
        )

        # 保存文件
        df.to_csv(output_name, index=False, encoding="utf-8-sig")
        print(f"✅ 文件处理完成，结果保存为: {output_name}")
        return df

    except Exception as e:
        print(f"❌ 错误: {e}")
        return None

# 主程序入口
if __name__ == "__main__":
    df1_result = process_file(FILE1, ["款型", "车型"], "/Users/zhengruinan/Desktop/cars.csv")
    df2_result = process_file(FILE2, ["车型名称"], "/Users/zhengruinan/Desktop/autohome.csv")