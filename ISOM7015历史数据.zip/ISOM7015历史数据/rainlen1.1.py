import pandas as pd
from rapidfuzz import fuzz, process  # 使用快速模糊匹配库
#from fuzzywuzzy import fuzz, process
from tqdm import tqdm  # 显示进度条
import datetime
import time
import os

# Step 1：倒计时提示函数
def countdown(seconds, message):
    print(f"{message}，请稍候...")
    for i in range(seconds, 0, -1):
        print(f"倒计时：{i} 秒", end="\r")
        time.sleep(1)
    print("\n开始执行...")

# Step 2：加载数据
try:
    countdown(2, "正在加载数据文件")
    sales_path = '/Users/zhengruinan/Desktop/周一商分基础/group/sales data.csv'
    cars_path = '/Users/zhengruinan/Desktop/周一商分基础/group/cars to match.csv'
    autohome_path = '/Users/zhengruinan/Desktop/周一商分基础/group/autohome merged for matching.csv'

    # 检查文件是否存在
    for path in [sales_path, cars_path, autohome_path]:
        if not os.path.exists(path):
            raise FileNotFoundError(f"文件不存在: {path}")

    # 读取CSV文件
    sales = pd.read_csv(sales_path, low_memory=False)
    cars = pd.read_csv(cars_path, low_memory=False)
    autohome = pd.read_csv(autohome_path, low_memory=False)
    print("✅ 数据加载完成")
except Exception as e:
    print("❌ 数据加载失败:", e)
    exit()

# Step 3：清洗文本字段
def clean_text(text):
    if pd.isna(text):
        return ""
    text = str(text).strip().upper()
    text = text.replace("款", "").replace("版", "")
    return text

try:
    countdown(2, "正在清洗文本字段")
    for col in ["品牌", "车型", "款型"]:
        if col in sales.columns:
            sales[col] = sales[col].apply(clean_text)
        if col in cars.columns:
            cars[col] = cars[col].apply(clean_text)
    for col in ["品牌名称", "车系名称", "车型名称"]:
        if col in autohome.columns:
            autohome[col] = autohome[col].apply(clean_text)
    print("✅ 文本清洗完成")
except Exception as e:
    print("❌ 文本清洗失败:", e)
    exit()

# Step 4：精确匹配 cars ↔ autohome
try:
    countdown(2, "正在进行精确匹配")
    exact_matched = pd.merge(
        cars,
        autohome,
        left_on=["品牌", "车型", "款型"],
        right_on=["品牌名称", "车系名称", "车型名称"],
        how="inner",
        suffixes=('_cars', '_auto')
    )
    print(f"✅ 精确匹配完成，共匹配到 {len(exact_matched)} 条记录")
except Exception as e:
    print("❌ 精确匹配失败:", e)
    exact_matched = pd.DataFrame()

# Step 5：模糊匹配 cars ↔ autohome（对未匹配部分）
def fuzzy_match(row, choices, scorer=fuzz.token_sort_ratio, threshold=85):
    if not row:
        return None
    result = process.extractOne(row, choices, scorer=scorer)
    if result and result[1] >= threshold:
        return result[0]
    return None

try:
    countdown(2, "正在进行模糊匹配")
    matched_ids = exact_matched["车辆型号"].dropna().unique()
    cars_unmatched = cars[~cars["车辆型号"].isin(matched_ids)].copy()
    autohome_models = autohome["车型名称"].dropna().unique().tolist()
    tqdm.pandas(desc="模糊匹配款型")
    cars_unmatched["匹配车型名称"] = cars_unmatched["款型"].progress_apply(lambda x: fuzzy_match(x, autohome_models))
    fuzzy_matched = pd.merge(
        cars_unmatched,
        autohome,
        left_on="匹配车型名称",
        right_on="车型名称",
        how="left",
        suffixes=('_cars', '_auto')
    )
    print(f"✅ 模糊匹配完成，共匹配到 {len(fuzzy_matched)} 条记录")
except Exception as e:
    print("❌ 模糊匹配失败:", e)
    fuzzy_matched = pd.DataFrame()

# Step 6：合并所有匹配结果
try:
    countdown(2, "正在合并销售数据与匹配结果")
    all_matched = pd.concat([exact_matched, fuzzy_matched], ignore_index=True)
    all_matched.drop_duplicates(subset=["品牌", "车型", "款型"], inplace=True)
    final_merged = pd.merge(
        sales,
        all_matched,
        on=["品牌", "车型"],
        how="left",
        suffixes=('_sales', '_match')
    )
    print(f"✅ 合并完成，共 {len(final_merged)} 行")
except Exception as e:
    print("❌ 合并失败:", e)
    exit()

# Step 7：标记匹配状态
try:
    final_merged["matched"] = final_merged["车型ID"].notna()
except Exception as e:
    print("❌ 匹配状态标记失败:", e)

# Step 8：提取未匹配数据
try:
    unmatched = final_merged[~final_merged["matched"]].copy()
except Exception as e:
    print("❌ 未匹配数据提取失败:", e)
    unmatched = pd.DataFrame()

# Step 9：输出结果文件（CSV格式）
try:
    countdown(2, "正在保存结果文件")
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    final_file = f"final_matched_{timestamp}.csv"
    unmatched_file = f"unmatched_{timestamp}.csv"

    final_merged.to_csv(final_file, index=False)
    unmatched.to_csv(unmatched_file, index=False)

    print(f"✅ 匹配结果已保存为：{final_file}")
    print(f"✅ 未匹配数据已保存为：{unmatched_file}")
except Exception as e:
    print("❌ 文件保存失败:", e)