
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# 读取数据
file_path = '/Users/zhengruinan/Desktop/周一商分基础/小组合并作业/10根据syj final修改的连贯代码/sales_data_1119.csv'
df = pd.read_csv(file_path)

# 列名
price_col = '厂商指导价(元)'
type_col = '燃料'

# 数据清理：价格 > 0 且 < 900000
df = df[(df[price_col] > 0) & (df[price_col] < 900000)]

# 设置字体
plt.rcParams['font.family'] = 'Songti SC'
plt.rcParams['axes.unicode_minus'] = False

# 绘制箱线图（使用单一颜色）
plt.figure(figsize=(12, 6))
sns.boxplot(x=type_col, y=price_col, data=df,
            color='#132020',  # 主色
            width=0.5,
            boxprops=dict(alpha=0.3),  # 低饱和度
            medianprops=dict(color='#132020', linewidth=2),
            whiskerprops=dict(color='#132020'),
            capprops=dict(color='#132020'),
            flierprops=dict(marker='o', markersize=4, color='#132020', alpha=0.4))

# 标题和标签
plt.title('Price Comparison: Gasoline vs EV', fontsize=14)
plt.ylabel('Price', fontsize=12)

# 去掉顶部和右侧边框
sns.despine()

# 添加淡淡的横向网格
plt.grid(axis='y', linestyle='--', alpha=0.2)

# 保存图表
plt.tight_layout()
plt.savefig('optimized_price_boxplot.png', dpi=300)
plt.show()
