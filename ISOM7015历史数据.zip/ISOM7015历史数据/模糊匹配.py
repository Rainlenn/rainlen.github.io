import pandas as pd  # 用來處理表格資料
import re  # 用來做文字清洗
from rapidfuzz import fuzz, process  # 用來做模糊匹配
from tqdm import tqdm  # 用來顯示進度條

# ✅ 詢問使用者是否只跑前 1000 筆資料
test_mode = input("是否只先測試前 1000 筆資料？(y/n): ").strip().lower()
if test_mode == 'y':
    test_limit = 1000
else:
    test_limit = None

# 1. 讀取資料
try:
    cars = pd.read_csv("/Users/zhengruinan/Desktop/cars.csv")
    autohome = pd.read_csv("/Users/zhengruinan/Desktop/autohome.csv")
    print("✅ 成功讀取資料")
except Exception as e:
    print(f"❌ 讀取資料時發生錯誤：{e}")
    exit()

# ✅ 若是測試模式，只保留前 N 筆資料
if test_limit:
    cars = cars.iloc[:test_limit].copy()

# 2. 定義清洗函數
def clean_text(text):
    if pd.isna(text):
        return ""
    text = str(text).lower()
    text = re.sub(r"\s+", "", text)
    text = re.sub(r"[^\w\d]", "", text)
    return text
# 3. 清洗並合併欄位
#cars_fields = ['企业', '品牌', '车型', '款型', '车辆型号', '排量', '燃料', '变速器', '车身类型']
#autohome_fields = ['品牌名称', '厂商名称', '车系名称', '车型名称', '年份', '厂商指导价(元)', '级别', '能源类型', '排量(L)', '车身结构', '变速箱']

cars_fields = ['唯一标识ID']
autohome_fields = ['唯一标识ID']

cars['combined'] = cars[cars_fields].fillna('').agg(' '.join, axis=1).apply(clean_text)
autohome['combined'] = autohome[autohome_fields].fillna('').agg(' '.join, axis=1).apply(clean_text)

# 4. 建立匹配鍵
autohome_keys = autohome['combined'].tolist()

# 5. 模糊匹配
matches = []
scores = []
matched_indices = []

print("🔍 開始進行模糊匹配...")
for car_text in tqdm(cars['combined']):
    try:
        match_result = process.extractOne(car_text, autohome_keys, scorer=fuzz.token_sort_ratio)
        if match_result:
            match_text, score, match_index = match_result
            matches.append(match_text)
            scores.append(round(score, 2))  # 保留兩位小數
            matched_indices.append(match_index)
        else:
            matches.append(None)
            scores.append(0.0)
            matched_indices.append(None)
    except Exception as e:
        print(f"⚠️ 匹配錯誤：{e}（輸入：{car_text}）")
        matches.append(None)
        scores.append(0.0)
        matched_indices.append(None)

# 6. 匹配結果合併原始資料
cars['matched_text'] = matches
cars['match_score'] = scores
cars['match_success'] = cars['match_score'].apply(lambda x: True if x >= 90 else False)  # 評價系統：90 分以上為成功

# 7. 合併匹配到的 autohome 原始資料
autohome_matched = autohome.iloc[matched_indices].reset_index(drop=True)
autohome_matched.columns = [f"匹配_{col}" if col != 'combined' else 'matched_text' for col in autohome_matched.columns]

# 8. 合併兩個表格
final_result = pd.concat([cars.reset_index(drop=True), autohome_matched], axis=1)

# 9. 儲存結果
output_path = "/Users/zhengruinan/Desktop/result.csv"
try:
    final_result.to_csv(output_path, index=False, encoding='utf-8-sig')
    print(f"✅ 匹配結果已儲存至：{output_path}")
except Exception as e:
    print(f"❌ 儲存結果時發生錯誤：{e}")