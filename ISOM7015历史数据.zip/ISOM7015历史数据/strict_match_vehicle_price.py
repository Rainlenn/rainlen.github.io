"""
车辆型号和款型严格匹配脚本
功能：根据车辆型号和款型（同年款）严格匹配两个数据集，将"matched_2&3"中的厂商指导价和匹配得分添加到"sales data"中。

匹配逻辑：
1. 首先精确匹配车辆型号。
2. 其次精确匹配年款（如'2020款'）。
3. 在相同车辆型号和年款的记录中，通过款型关键词进行匹配。
4. 关键词包括：版本名称（如旗韵版、尊雅版）、动力信息（如1.5T、370TURBO）、驱动方式（两驱/四驱）。
5. 版本名称的匹配权重最高（权重为10），其他关键词权重为1。
6. 选择得分最高的匹配结果作为最终匹配。
7. **严格要求**：如果最佳匹配的记录价格为空，则不匹配。
"""

import pandas as pd
import re
import numpy as np

# 定义常量
MATCHED_FILE = '/home/ubuntu/upload/matched_2&3.xlsx'
SALES_FILE = '/home/ubuntu/upload/salesdata.csv'
OUTPUT_FILE = '/home/ubuntu/sales_data_with_price_strict.xlsx'
OUTPUT_CODE = '/home/ubuntu/strict_match_vehicle_price.py'


def extract_keywords(text):
    """
    从款型文本中提取关键字段
    
    参数:
        text: 款型文本字符串
        
    返回:
        dict: 包含提取出的关键词的字典，包括年款
    """
    if pd.isna(text):
        return {'year': None, 'keywords': set()}
    text = str(text)
    keywords = set()
    year = None
    
    # 提取年款（如2020款、2021款）
    year_pattern = r'(\d{4}款)'
    year_match = re.search(year_pattern, text)
    if year_match:
        year = year_match.group(1)
        keywords.add(year)
    
    # 提取"XX版"模式的关键词（最重要）
    version_pattern = r'[\u4e00-\u9fa5]+版'
    versions = re.findall(version_pattern, text)
    keywords.update(versions)
    
    # 提取排量/动力信息（如1.5T、2.0L、370TURBO）
    power_pattern = r'\d+\.?\d*[TL]|TURBO|\d+TURBO'
    powers = re.findall(power_pattern, text)
    keywords.update(powers)
    
    # 提取驱动方式（两驱、四驱）
    drive_pattern = r'[两四]驱'
    drives = re.findall(drive_pattern, text)
    keywords.update(drives)
    
    return {'year': year, 'keywords': keywords}


def calculate_match_score(keywords1, keywords2):
    """
    计算两个关键字集合的匹配得分
    
    参数:
        keywords1: 第一个关键词集合
        keywords2: 第二个关键词集合
        
    返回:
        float: 匹配得分，版本名称匹配权重为10，其他关键词权重为1
    """
    if not keywords1 or not keywords2:
        return 0.0
    
    # 提取版本名称（以"版"结尾的关键词）
    versions1 = {k for k in keywords1 if k.endswith('版')}
    versions2 = {k for k in keywords2 if k.endswith('版')}
    
    # 版本名称完全匹配权重最高
    version_match = len(versions1 & versions2)
    
    # 其他关键词匹配
    other_keywords1 = keywords1 - versions1
    other_keywords2 = keywords2 - versions2
    other_match = len(other_keywords1 & other_keywords2)
    
    # 计算得分：版本匹配权重为10，其他关键词权重为1
    score = version_match * 10.0 + other_match * 1.0
    
    return score


def match_vehicle_price_strict(matched_file_path, sales_file_path):
    """
    主函数：执行车辆型号和款型严格匹配，添加厂商指导价和得分
    
    参数:
        matched_file_path: matched_2&3.xlsx 文件路径
        sales_file_path: salesdata.csv 文件路径
        
    返回:
        tuple: (匹配后的DataFrame, 匹配统计信息字典)
    """
    print("=" * 60)
    print("车辆型号和款型严格匹配程序")
    print("=" * 60)
    
    # 1. 读取数据文件
    print("\n[步骤 1/5] 读取数据文件...")
    matched_df = pd.read_excel(matched_file_path)
    sales_df = pd.read_csv(sales_file_path)
    
    print(f"  - matched_2&3.xlsx: {len(matched_df):,} 行")
    print(f"  - salesdata.csv: {len(sales_df):,} 行")
    
    # 2. 提取关键词和年款
    print("\n[步骤 2/5] 提取款型关键词和年款...")
    matched_df['extracted'] = matched_df['款型'].apply(extract_keywords)
    sales_df['extracted'] = sales_df['款型'].apply(extract_keywords)
    
    matched_df['year'] = matched_df['extracted'].apply(lambda x: x['year'])
    matched_df['keywords'] = matched_df['extracted'].apply(lambda x: x['keywords'])
    
    sales_df['year'] = sales_df['extracted'].apply(lambda x: x['year'])
    sales_df['keywords'] = sales_df['extracted'].apply(lambda x: x['keywords'])
    
    matched_df = matched_df.drop('extracted', axis=1)
    sales_df = sales_df.drop('extracted', axis=1)
    print("  - 关键词和年款提取完成")
    
    # 3. 构建匹配字典 (以 车辆型号 和 年款 为键)
    print("\n[步骤 3/5] 构建匹配字典...")
    matched_dict = {}
    for idx, row in matched_df.iterrows():
        vehicle_model = row['车辆型号']
        year = row['year']
        
        # 严格匹配：只考虑有年款的记录
        if pd.isna(vehicle_model) or year is None:
            continue
            
        key = (vehicle_model, year)
        
        if key not in matched_dict:
            matched_dict[key] = []
            
        matched_dict[key].append({
            'keywords': row['keywords'],
            'price': row['厂商指导价(元)'],
            'model_name': row['款型']
        })
    
    print(f"  - 共有 {len(matched_dict):,} 个不同的 (车辆型号, 年款) 组合")
    
    # 4. 执行严格匹配
    print("\n[步骤 4/5] 执行严格匹配...")
    
    def find_best_match_strict(row):
        """为给定的销售记录找到同年款的最佳匹配"""
        vehicle_model = row['车辆型号']
        year = row['year']
        sales_keywords = row['keywords']
        
        # 严格匹配：必须有年款
        if year is None:
            return None, None
            
        key = (vehicle_model, year)
        
        if key not in matched_dict:
            return None, None
        
        candidates = matched_dict[key]
        best_score = -1.0
        best_price = None
        
        for candidate in candidates:
            # 严格要求：只考虑有价格的候选项
            if pd.isna(candidate['price']):
                continue
                
            score = calculate_match_score(sales_keywords, candidate['keywords'])
            
            # 匹配精度优先：选择得分最高的
            if score > best_score:
                best_score = score
                best_price = candidate['price']
        
        # 只有得分大于0才算成功匹配
        if best_score > 0.0:
            return best_price, best_score
        
        return None, None

    # 应用匹配函数
    results = sales_df.apply(find_best_match_strict, axis=1, result_type='expand')
    sales_df['厂商指导价(元)'] = results[0]
    sales_df['匹配评分规则得分'] = results[1]
    
    # 删除临时的keywords和year列
    sales_df = sales_df.drop(['keywords', 'year'], axis=1)
    
    # 5. 统计匹配结果
    print("\n[步骤 5/5] 统计匹配结果...")
    matched_count = sales_df['厂商指导价(元)'].notna().sum()
    total_count = len(sales_df)
    match_rate = matched_count / total_count * 100
    
    # 打印统计信息
    print("\n" + "=" * 60)
    print("匹配统计")
    print("=" * 60)
    print(f"总记录数: {total_count:,}")
    print(f"成功匹配: {matched_count:,}")
    print(f"未匹配: {total_count - matched_count:,}")
    print(f"匹配率: {match_rate:.2f}%")
    print("=" * 60)
    
    # 返回结果
    stats = {
        'total_count': total_count,
        'matched_count': matched_count,
        'unmatched_count': total_count - matched_count,
        'match_rate': match_rate
    }
    
    return sales_df, stats


def save_to_excel(df, output_path):
    """
    将DataFrame保存为Excel文件，如果行数超过限制则分表保存
    """
    MAX_ROWS = 1048576
    if len(df) <= MAX_ROWS:
        df.to_excel(output_path, index=False)
        print(f"  - 结果已保存到: {output_path}")
    else:
        print(f"  - 数据行数 ({len(df):,}) 超过Excel单表限制 ({MAX_ROWS:,})，将分表保存。")
        writer = pd.ExcelWriter(output_path, engine='xlsxwriter')
        num_sheets = (len(df) + MAX_ROWS - 1) // MAX_ROWS
        for i in range(num_sheets):
            start = i * MAX_ROWS
            end = min((i + 1) * MAX_ROWS, len(df))
            sheet_name = f'Sheet{i+1}'
            df.iloc[start:end].to_excel(writer, sheet_name=sheet_name, index=False)
            print(f"    - 保存 {sheet_name}: {start+1:,} - {end:,} 行")
        writer.close()
        print(f"  - 结果已分表保存到: {output_path}")


def display_match_examples(sales_df, vehicle_models=None, n=5):
    """
    显示匹配示例
    """
    print("\n" + "=" * 60)
    print("匹配示例")
    print("=" * 60)
    
    if vehicle_models:
        for vm in vehicle_models:
            print(f"\n车辆型号: {vm}")
            results = sales_df[sales_df['车辆型号'] == vm][['车辆型号', '款型', '厂商指导价(元)', '匹配评分规则得分']].head(n)
            if len(results) > 0:
                print(results.to_string(index=False))
            else:
                print("  未找到该车辆型号的记录")
    else:
        print("\n随机匹配成功的记录:")
        results = sales_df[sales_df['厂商指导价(元)'].notna()][['车辆型号', '款型', '厂商指导价(元)', '匹配评分规则得分']].sample(n=n, random_state=42)
        print(results.to_string(index=False))


if __name__ == "__main__":
    # 执行匹配
    result_df, stats = match_vehicle_price_strict(MATCHED_FILE, SALES_FILE)
    
    # 保存结果
    save_to_excel(result_df, OUTPUT_FILE)
    
    # 显示匹配示例
    display_match_examples(
        result_df, 
        vehicle_models=['CA7150HA6T', 'DHW6483T5ASF'],
        n=5
    )
    
    print("\n处理完成！")
