// pages/community/community.ts
Page({
  data: {
    activeTab: 0,
    tabs: ['All', 'Hot', 'Latest'],
    posts: [
      {
        id: 1,
        username: 'TechInvestor2024',
        level: 10,
        avatar: 'http://t6l4qo0q9.hn-bkt.clouddn.com/user-1.jpg',
        time: '3 hours ago',
        title: 'Tech Stocks at a Crossroads: AI Boom vs. Rate Hike Concerns',
        content: "As the Federal Reserve's interest rate hike cycle nears its end, global capital markets stand at a critical turning point...",
        images: ['http://t6l4qo0q9.hn-bkt.clouddn.com/stock-trend.png'],
        likes: 89,
        comments: 15,
        commentsPreview: [
          {
            username: 'ValueSeeker88',
            avatar: 'http://t6l4qo0q9.hn-bkt.clouddn.com/user-2.jpg',
            time: '2 hours ago',
            content: "The tech sector's sky-high valuations are a sword of Damocles..."
          },
          {
            username: 'AIInsider123',
            avatar: 'http://t6l4qo0q9.hn-bkt.clouddn.com/user3.jpg',
            time: '2 hours ago',
            content: "Computing infrastructure investment is still in the acceleration phase..."
          }
        ]
      },
      {
        id: 2,
        username: 'Investor_John',
        level: 8,
        avatar: 'http://t6l4qo0q9.hn-bkt.clouddn.com/user-2.jpg',
        time: '5 hours ago',
        title: 'AAPL is looking strong after earnings!',
        content: "Just read the latest report and the fundamentals are solid. Revenue growth is impressive and the new product line looks promising...",
        likes: 24,
        comments: 8
      },
      {
        id: 3,
        username: 'NewInvestor',
        level: 3,
        avatar: 'http://t6l4qo0q9.hn-bkt.clouddn.com/user3.jpg',
        time: '1 day ago',
        title: 'Just started investing - any tips?',
        content: 'New to the platform and stock investing. Would love to hear from experienced investors about best practices...',
        likes: 18,
        comments: 12
      },
      {
        id: 4,
        username: 'StockMaster',
        level: 15,
        avatar: 'http://t6l4qo0q9.hn-bkt.clouddn.com/user4.jpg',
        time: '2 days ago',
        title: 'Weekly market recap',
        content: 'Here\'s my analysis of this week\'s market movements and key events that impacted major stocks...',
        likes: 56,
        comments: 23
      }
    ]
  },

  onLoad() {
    // 加载社区数据
  },

  onTabChange(e: any) {
    this.setData({
      activeTab: e.detail.value
    })
  },

  createPost() {
    wx.navigateTo({
      url: '/subpages/create-post/create-post'
    })
  },

  likePost(e: any) {
    const id = e.currentTarget.dataset.id
    // 处理点赞
    console.log('Like post:', id)
  },

  commentPost(e: any) {
    const id = e.currentTarget.dataset.id
    // 处理评论
    console.log('Comment post:', id)
  },

  sharePost(e: any) {
    const id = e.currentTarget.dataset.id
    // 处理分享
    console.log('Share post:', id)
  },

  viewPost(e: any) {
    const id = e.currentTarget.dataset.id
    wx.navigateTo({
      url: `/subpages/post-detail/post-detail?id=${id}`
    })
  }
})

