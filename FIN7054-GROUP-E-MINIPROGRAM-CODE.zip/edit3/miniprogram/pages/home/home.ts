// pages/home/home.ts
Page({
  data: {
    userInfo: {
      avatar: "/images/avatar-default.png"
    },
    petInfo: {
      name: "Golden Dog",
      level: 5,
      status: "Happy",
      coins: 1250,
      mood: 85,
      moodMax: 100,
      avatar: "http://t6l4qo0q9.hn-bkt.clouddn.com/pet-dog.jpg"
    },
    stats: {
      reportsRead: 24,
      daysActive: 12,
      ranking: 8
    },
    todayReading: [
      {
        id: 1,
        title: "AAPL Analysis Report",
        subtitle: "Apple Inc. Q4 Earnings Review",
        readTime: "5 min read",
        coins: 10,
        icon: "chart-line"
      },
      {
        id: 2,
        title: "Tech Sector Outlook",
        subtitle: "Industry Analysis & Trends",
        readTime: "8 min read",
        coins: 16,
        icon: "industry"
      }
    ],
    recommendedStocks: [
      {
        symbol: "AAPL",
        name: "Apple Inc.",
        price: 178.50,
        change: 2.34,
        changePercent: 2.34,
        changeAmount: 4.08
      },
      {
        symbol: "TSLA",
        name: "Tesla Inc.",
        price: 245.20,
        change: -1.12,
        changePercent: -1.12,
        changeAmount: 2.78
      }
    ]
  },

  onLoad() {
    // 初始化数据
  },

  onShow() {
    // 页面显示时刷新数据
  },

  viewAllReports() {
    wx.switchTab({
      url: '/pages/reports/reports'
    })
  },

  viewAllStocks() {
    wx.switchTab({
      url: '/pages/investment/investment'
    })
  },

  viewRanking() {
    wx.navigateTo({
      url: '/subpages/ranking/ranking'
    })
  },

  viewReport(e: any) {
    const id = e.currentTarget.dataset.id
    wx.navigateTo({
      url: `/subpages/report-detail/report-detail?id=${id}`
    })
  },

  viewStockDetail(e: any) {
    const symbol = e.currentTarget.dataset.symbol
    wx.navigateTo({
      url: `/subpages/stock-detail/stock-detail?symbol=${symbol}`
    })
  }
})

