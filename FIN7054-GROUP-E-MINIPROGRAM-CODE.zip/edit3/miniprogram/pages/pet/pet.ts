// pages/pet/pet.ts
Page({
  data: {
    petInfo: {
      name: 'Golden Dog',
      level: 5,
      status: 'Happy',
      coins: 1250,
      mood: 85,
      moodMax: 100,
      exp: 2450,
      expMax: 3000,
      avatar: 'http://t6l4qo0q9.hn-bkt.clouddn.com/pet-dog.jpg'
    },
    expPercentage: 82,
    activeTab: 0,
    tabs: ['Shop', 'Outfit'],
    shopItems: [
      {
        id: 1,
        name: 'Golden Crown',
        type: 'Rare',
        moodBonus: 5,
        price: 500,
        icon: 'crown',
        image: 'http://t6l4qo0q9.hn-bkt.clouddn.com/golden-crown.png',
        available: true
      },
      {
        id: 2,
        name: 'Blue Shirt',
        type: 'Common',
        moodBonus: 2,
        price: 150,
        icon: 'shirt',
        image: 'http://t6l4qo0q9.hn-bkt.clouddn.com/blue-shirt.png',
        available: true
      },
      {
        id: 3,
        name: 'Cool Glasses',
        type: 'Uncommon',
        moodBonus: 3,
        price: 250,
        icon: 'glasses',
        image: 'http://t6l4qo0q9.hn-bkt.clouddn.com/cool-glasses.png',
        available: true
      },
      {
        id: 4,
        name: 'Wizard Hat',
        type: 'Epic',
        moodBonus: 8,
        price: 800,
        icon: 'hat',
        image: 'http://t6l4qo0q9.hn-bkt.clouddn.com/wizard-hat.png',
        available: false
      }
    ],
    levelBenefits: [
      {
        level: '1-3',
        benefit: 'Basic reports access',
        unlocked: true
      },
      {
        level: '4-6',
        benefit: 'Advanced reports + Stock recommendations',
        unlocked: true
      },
      {
        level: '7-10',
        benefit: 'Premium reports + Priority support',
        unlocked: false
      }
    ]
  },

  onLoad() {
    // 加载宠物数据
  },

  onTabChange(e: any) {
    this.setData({
      activeTab: e.detail.value
    })
  },

  buyItem(e: any) {
    const id = e.currentTarget.dataset.id
    const item = this.data.shopItems.find(i => i.id === id)
    if (item && item.available && this.data.petInfo.coins >= item.price) {
      wx.showToast({
        title: 'Purchase successful!',
        icon: 'success'
      })
      // 更新金币和心情值
      this.setData({
        'petInfo.coins': this.data.petInfo.coins - item.price,
        'petInfo.mood': Math.min(this.data.petInfo.mood + item.moodBonus, this.data.petInfo.moodMax)
      })
    } else if (item && !item.available) {
      wx.showToast({
        title: 'Item locked',
        icon: 'none'
      })
    } else {
      wx.showToast({
        title: 'Insufficient coins',
        icon: 'none'
      })
    }
  }
})

