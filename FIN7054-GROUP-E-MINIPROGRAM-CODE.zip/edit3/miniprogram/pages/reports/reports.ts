// pages/reports/reports.ts
Page({
  data: {
    searchValue: '',
    activeTab: 0,
    tabs: ['All', 'Stocks', 'Industry', 'Trending'],
    readingTimer: {
      time: 45,
      coins: 1
    },
    timerMinutes: 0,
    timerSeconds: '45',
    reports: [
      {
        id: 1,
        category: 'Stock',
        categoryColor: 'yellow',
        time: '2 hours ago',
        title: 'AAPL Q4 2024 Earnings Analysis',
        description: "Comprehensive review of Apple's quarterly performance, revenue growth, and future outlook...",
        readTime: '12 min',
        coins: 24,
        views: '1.2k',
        author: 'Goldman Sachs Research'
      },
      {
        id: 2,
        category: 'Industry',
        categoryColor: 'blue',
        time: '5 hours ago',
        title: 'Tech Sector Q4 Outlook',
        description: 'Analysis of technology sector trends, key players, and investment opportunities...',
        readTime: '15 min',
        coins: 30,
        views: '856',
        author: 'Morgan Stanley'
      },
      {
        id: 3,
        category: 'Stock',
        categoryColor: 'yellow',
        time: '1 day ago',
        title: 'TSLA Market Position Review',
        description: "Deep dive into Tesla's competitive advantages and market strategy...",
        readTime: '10 min',
        coins: 20,
        views: '2.1k',
        author: 'JP Morgan'
      },
      {
        id: 4,
        category: 'Trending',
        categoryColor: 'green',
        time: '2 days ago',
        title: 'AI Investment Opportunities',
        description: 'Exploring artificial intelligence sector growth and top investment picks...',
        readTime: '18 min',
        coins: 36,
        views: '3.5k',
        author: 'Barclays Research'
      }
    ]
  },

  onLoad() {
    // 初始化计时器显示
    const time = this.data.readingTimer.time
    const minutes = Math.floor(time / 60)
    const seconds = time % 60
    this.setData({
      timerMinutes: minutes,
      timerSeconds: seconds < 10 ? '0' + seconds : seconds
    })
    // 开始阅读计时
    this.startReadingTimer()
  },

  onUnload() {
    // 停止计时器
    if (this.timer) {
      clearInterval(this.timer)
    }
  },

  startReadingTimer() {
    this.timer = setInterval(() => {
      const time = this.data.readingTimer.time + 1
      const coins = Math.floor(time / 30)
      const minutes = Math.floor(time / 60)
      const seconds = time % 60
      this.setData({
        'readingTimer.time': time,
        'readingTimer.coins': coins,
        timerMinutes: minutes,
        timerSeconds: seconds < 10 ? '0' + seconds : seconds
      })
    }, 1000)
  },

  onSearch(e: any) {
    this.setData({
      searchValue: e.detail.value
    })
  },

  onTabChange(e: any) {
    this.setData({
      activeTab: e.detail.value
    })
  },

  viewReport(e: any) {
    const id = e.currentTarget.dataset.id
    // 跳转到报告详情页
    wx.navigateTo({
      url: `/subpages/report-detail/report-detail?id=${id}`
    })
  }
})

