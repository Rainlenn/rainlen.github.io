// pages/investment/investment.ts
Page({
  data: {
    portfolio: {
      totalValue: 125430.50,
      todayChange: 2340.20,
      todayChangePercent: 1.90
    },
    bankAccount: {
      account: '****1234',
      available: 50000.00
    },
    holdings: [
      {
        symbol: 'AAPL',
        name: 'Apple Inc.',
        shares: 50,
        avgPrice: 175.20,
        currentPrice: 178.50,
        value: 8925.00,
        change: 2.34,
        changePercent: 2.34
      },
      {
        symbol: 'TSLA',
        name: 'Tesla Inc.',
        shares: 30,
        avgPrice: 248.50,
        currentPrice: 245.20,
        value: 7356.00,
        change: -1.12,
        changePercent: -1.12
      },
      {
        symbol: 'MSFT',
        name: 'Microsoft Corp.',
        shares: 25,
        avgPrice: 360.20,
        currentPrice: 365.00,
        value: 9125.00,
        change: 1.85,
        changePercent: 1.85
      }
    ],
    recommended: [
      {
        symbol: 'NVDA',
        name: 'NVIDIA Corp.',
        price: 485.20,
        change: 3.45,
        changeAmount: '16.20'
      },
      {
        symbol: 'GOOGL',
        name: 'Alphabet Inc.',
        price: 142.80,
        change: 2.12,
        changeAmount: '2.96'
      },
      {
        symbol: 'AMZN',
        name: 'Amazon.com Inc.',
        price: 178.50,
        change: -0.85,
        changeAmount: '1.52'
      }
    ],
    transactions: [
      {
        type: 'Bought',
        symbol: 'AAPL',
        shares: 50,
        price: 175.20,
        amount: -8760.00,
        amountDisplay: '8,760.00',
        time: '2 days ago'
      },
      {
        type: 'Sold',
        symbol: 'TSLA',
        shares: 20,
        price: 250.00,
        amount: 5000.00,
        amountDisplay: '5,000.00',
        time: '5 days ago'
      },
      {
        type: 'Bought',
        symbol: 'MSFT',
        shares: 25,
        price: 360.20,
        amount: -9005.00,
        amountDisplay: '9,005.00',
        time: '1 week ago'
      }
    ]
  },

  onLoad() {
    // 加载投资数据
  },

  addFunds() {
    wx.showToast({
      title: 'Add Funds',
      icon: 'none'
    })
  },

  viewAllHoldings() {
    // 查看所有持仓
  },

  viewAllRecommended() {
    // 查看所有推荐
  },

  viewStockDetail(e: any) {
    const symbol = e.currentTarget.dataset.symbol
    wx.navigateTo({
      url: `/subpages/stock-detail/stock-detail?symbol=${symbol}`
    })
  }
})

