// pages/report-detail/report-detail.ts
Page({
  data: {
    reportId: 0,
    readingProgress: 0,
    coinsEarned: 0,
    readingTime: 0,
    report: {
      id: 1,
      category: 'Industry',
      categoryColor: 'blue',
      time: '2024-11-30',
      title: 'Machinery Industry Weekly: Humanoid Robot Industry Catalysts Continue, Focus on Related Sector Targets',
      author: 'Pacific Securities Research',
      readTime: '15 min',
      views: '2.3k',
      coins: 30,
      summary: 'The machinery industry performed steadily this week, with the humanoid robot sector continuing to benefit from policy and industry catalysts. With technological breakthroughs and expanding application scenarios, companies in the related industrial chain are welcoming development opportunities. We recommend focusing on core components, body manufacturing, and high-quality targets in downstream application areas.',
      overview: 'The machinery industry showed overall stable performance this week, with the humanoid robot sector standing out. At the policy level, the Ministry of Industry and Information Technology released the "Guidance on Innovation and Development of Humanoid Robots," clarifying the goal of mass production by 2025. At the industry level, multiple leading companies released new products, accelerating technological iteration. At the market level, funds continue to flow into related concept stocks, and sector valuations are expected to further increase.',
      highlights: [
        'Policy support strengthened, humanoid robots included in national strategic emerging industries',
        'Core technology breakthroughs, localization rate of key components such as reducers and servo motors improved',
        'Application scenarios expanded from industrial manufacturing to services, healthcare and other fields',
        'Industrial chain synergy effects emerging, cooperation between upstream and downstream companies deepening',
        'International competitive landscape changing, Chinese companies leading in some areas'
      ],
      recommendation: 'Maintain "Overweight" rating for the industry. We recommend focusing on: 1) Core component companies, benefiting from domestic substitution and demand growth; 2) Humanoid robot body manufacturers with leading technology and mass production capabilities; 3) System integrators with rich downstream application scenarios. Short-term focus on thematic investment opportunities from policy catalysts and new product releases, long-term optimistic about performance realization after industrial chain maturity.',
      relatedStocks: [
        { symbol: '300024', name: 'Siasun Robot' },
        { symbol: '002747', name: 'Estun Automation' },
        { symbol: '688169', name: 'Roborock' },
        { symbol: '300450', name: 'Wuxi Lead' },
        { symbol: '002008', name: 'Han\'s Laser' }
      ],
      risks: '1) Technology R&D progress below expectations; 2) Downstream demand below expectations; 3) Intensified market competition; 4) Policy support below expectations; 5) Core component supply chain risks; 6) Product commercialization progress below expectations.'
    }
  },

  onLoad(options: any) {
    const reportId = options.id || 1
    this.setData({
      reportId: reportId
    })
    // 实际应用中这里应该根据 reportId 从服务器获取数据
    this.startReadingTimer()
  },

  onUnload() {
    if (this.timer) {
      clearInterval(this.timer)
    }
  },

  onPageScroll(e: any) {
    // 根据滚动位置更新阅读进度
    const scrollTop = e.scrollTop
    const scrollHeight = 3000 // 估算的内容高度
    const progress = Math.min(Math.floor((scrollTop / scrollHeight) * 100), 100)
    this.setData({
      readingProgress: progress
    })
  },

  startReadingTimer() {
    this.timer = setInterval(() => {
      const time = this.data.readingTime + 1
      const coins = Math.floor(time / 30)
      this.setData({
        readingTime: time,
        coinsEarned: coins
      })
    }, 1000)
  },

  finishReading() {
    wx.showToast({
      title: `Earned ${this.data.report.coins} coins!`,
      icon: 'success'
    })
    setTimeout(() => {
      wx.navigateBack()
    }, 1500)
  },

  shareReport() {
    wx.showToast({
      title: 'Share feature coming soon',
      icon: 'none'
    })
  },

  saveReport() {
    wx.showToast({
      title: 'Saved successfully',
      icon: 'success'
    })
  }
})
