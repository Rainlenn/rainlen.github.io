// pages/post-detail/post-detail.ts
Page({
  data: {
    postId: 0,
    commentInput: '',
    currentUserAvatar: 'http://t6l4qo0q9.hn-bkt.clouddn.com/user-1.jpg',
    post: {
      id: 1,
      username: 'TechInvestor2024',
      level: 10,
      avatar: 'http://t6l4qo0q9.hn-bkt.clouddn.com/user-1.jpg',
      time: '3 hours ago',
      title: 'Tech Stocks at a Crossroads: AI Boom vs. Rate Hike Concerns',
      content: 'As the Federal Reserve\'s interest rate hike cycle nears its end, global capital markets stand at a critical turning point. Driven by the explosive demand for AI computing power, the tech sector outperformed the broader market in the first half of the year, but lofty valuations have sparked growing concerns among investors. This article analyzes the investment logic and potential risks for tech stocks in the second half of the year, combining macroeconomic data and industry dynamics.',
      images: ['http://t6l4qo0q9.hn-bkt.clouddn.com/stock-trend.png'],
      views: 1234,
      likes: 89,
      comments: 15,
      isLiked: false
    },
    commentsList: [
      {
        id: 1,
        username: 'ValueSeeker88',
        level: 8,
        avatar: 'http://t6l4qo0q9.hn-bkt.clouddn.com/user-2.jpg',
        time: '2 hours ago',
        content: 'The tech sector\'s sky-high valuations are a sword of Damocles. Without sustained earnings beats, a correction could happen anytime. I\'m shifting some positions to undervalued consumer staples.',
        likes: 12
      },
      {
        id: 2,
        username: 'AIInsider123',
        level: 12,
        avatar: 'http://t6l4qo0q9.hn-bkt.clouddn.com/user3.jpg',
        time: '2 hours ago',
        content: 'Computing infrastructure investment is still in the acceleration phase. Upstream players like NVIDIA and TSMC have stronger certainty – worth a long-term layout. Don\'t sleep on domestic AI chip makers either!',
        likes: 24
      },
      {
        id: 3,
        username: 'RetailInvestorNewbie',
        level: 3,
        avatar: 'http://t6l4qo0q9.hn-bkt.clouddn.com/user-1.jpg',
        time: '1 hour ago',
        content: 'Just chased a chip stock last week and now I\'m panicking… Any experts here advise holding or cutting losses? 😰',
        likes: 5
      },
      {
        id: 4,
        username: 'MacroTraderPro',
        level: 15,
        avatar: 'http://t6l4qo0q9.hn-bkt.clouddn.com/user-2.jpg',
        time: '1 hour ago',
        content: 'Fed\'s dot plot suggests two more hikes this year – don\'t underestimate the hawkish risks. Tech stocks are sensitive to interest rate fluctuations, so position sizing is key.',
        likes: 18
      },
      {
        id: 5,
        username: 'GrowthStockFan',
        level: 9,
        avatar: 'http://t6l4qo0q9.hn-bkt.clouddn.com/user4.jpg',
        time: '30 min ago',
        content: 'AI adoption is happening faster than expected across industries. SaaS companies with AI integration are posting 30%+ revenue growth – that\'s where the real opportunities lie, not just hardware.',
        likes: 15
      }
    ]
  },

  onLoad(options: any) {
    const postId = options.id || 1
    this.setData({
      postId: postId
    })
    // 实际应用中根据 postId 从服务器获取数据
  },

  onCommentInput(e: any) {
    this.setData({
      commentInput: e.detail.value
    })
  },

  toggleLike() {
    const isLiked = !this.data.post.isLiked
    const likes = isLiked ? this.data.post.likes + 1 : this.data.post.likes - 1
    this.setData({
      'post.isLiked': isLiked,
      'post.likes': likes
    })
    wx.showToast({
      title: isLiked ? 'Liked!' : 'Unliked',
      icon: 'success'
    })
  },

  sharePost() {
    wx.showToast({
      title: 'Share feature coming soon',
      icon: 'none'
    })
  },

  likeComment(e: any) {
    const id = e.currentTarget.dataset.id
    const comments = this.data.commentsList.map(comment => {
      if (comment.id === id) {
        return { ...comment, likes: comment.likes + 1 }
      }
      return comment
    })
    this.setData({
      commentsList: comments
    })
  },

  replyComment(e: any) {
    const id = e.currentTarget.dataset.id
    const comment = this.data.commentsList.find(c => c.id === id)
    if (comment) {
      this.setData({
        commentInput: `@${comment.username} `
      })
    }
  },

  submitComment() {
    if (!this.data.commentInput.trim()) {
      wx.showToast({
        title: 'Please enter a comment',
        icon: 'none'
      })
      return
    }

    const newComment = {
      id: this.data.commentsList.length + 1,
      username: 'CurrentUser',
      level: 5,
      time: 'Just now',
      content: this.data.commentInput,
      likes: 0
    }

    this.setData({
      commentsList: [newComment, ...this.data.commentsList],
      commentInput: '',
      'post.comments': this.data.post.comments + 1
    })

    wx.showToast({
      title: 'Comment posted!',
      icon: 'success'
    })
  },

  previewImage(e: any) {
    const url = e.currentTarget.dataset.url
    wx.previewImage({
      current: url,
      urls: this.data.post.images
    })
  }
})
