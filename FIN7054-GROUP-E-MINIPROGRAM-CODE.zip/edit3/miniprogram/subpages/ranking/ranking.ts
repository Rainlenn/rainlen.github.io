// pages/ranking/ranking.ts
Page({
  data: {
    activeTab: 0,
    tabs: ['Reading', 'Coins', 'Level'],
    myRank: {
      rank: 8,
      reportsRead: 24,
      coins: 1250,
      level: 5
    },
    topThree: [
      {
        rank: 2,
        username: 'Investor_Pro',
        level: 15,
        reportsRead: 156,
        coins: 15600,
        avatar: ''
      },
      {
        rank: 1,
        username: 'TradingMaster',
        level: 18,
        reportsRead: 203,
        coins: 20300,
        avatar: ''
      },
      {
        rank: 3,
        username: 'FinanceGuru',
        level: 12,
        reportsRead: 142,
        coins: 14200,
        avatar: ''
      }
    ],
    rankingList: [
      {
        rank: 4,
        username: 'StockAnalyst',
        level: 11,
        reportsRead: 128,
        coins: 12450,
        avatar: ''
      },
      {
        rank: 5,
        username: 'MarketWatcher',
        level: 10,
        reportsRead: 115,
        coins: 11200,
        avatar: ''
      },
      {
        rank: 6,
        username: 'Investor_John',
        level: 8,
        reportsRead: 98,
        coins: 9800,
        avatar: ''
      },
      {
        rank: 7,
        username: 'TradingPro',
        level: 9,
        reportsRead: 87,
        coins: 8700,
        avatar: ''
      },
      {
        rank: 9,
        username: 'NewInvestor',
        level: 3,
        reportsRead: 18,
        coins: 900,
        avatar: ''
      },
      {
        rank: 10,
        username: 'Beginner123',
        level: 2,
        reportsRead: 12,
        coins: 600,
        avatar: ''
      }
    ]
  },

  onLoad() {
    // 加载排行榜数据
  },

  onTabChange(e: any) {
    this.setData({
      activeTab: e.detail.value
    })
  },

  getRankBadgeClass(rank: number) {
    if (rank === 1) return 'rank-1'
    if (rank === 2) return 'rank-2'
    if (rank === 3) return 'rank-3'
    return 'rank-other'
  }
})

