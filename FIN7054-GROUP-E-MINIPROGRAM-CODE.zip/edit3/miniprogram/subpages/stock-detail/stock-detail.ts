// pages/stock-detail/stock-detail.ts
Page({
  data: {
    stockSymbol: '',
    activeTimePeriod: 0,
    timePeriods: ['1D', '5D', '1M', '3M', 'YTD', '1Y', '3Y', '5Y', 'Max'],
    stock: {
      symbol: 'AAPL',
      name: 'Apple Inc.',
      price: '3,914.01',
      change: 0.65,
      changeAmount: '25.41',
      updateTime: 'Dec 1st 15:00 CST',
      open: '3,888.60',
      high: '3,920.00',
      low: '3,888.60',
      volume: '245.6M',
      marketCap: '$2.95T',
      peRatio: '28.5'
    },
    relatedIndices: [
      {
        symbol: '000001',
        name: 'Shanghai Composite',
        price: '3,914.01',
        change: 0.65
      },
      {
        symbol: 'DJI',
        name: 'Dow Jones Industrial',
        price: '47,716.42',
        change: 0.61
      },
      {
        symbol: 'INX',
        name: 'S&P 500',
        price: '6,849.09',
        change: 0.54
      },
      {
        symbol: 'COMP',
        name: 'NASDAQ Composite',
        price: '23,365.69',
        change: 0.65
      },
      {
        symbol: 'UKX',
        name: 'FTSE 100',
        price: '9,720.51',
        change: 0.27
      },
      {
        symbol: 'NIFTY',
        name: 'NIFTY 50',
        price: '26,182.85',
        change: -0.08
      },
      {
        symbol: 'NDX',
        name: 'NASDAQ 100',
        price: '25,434.89',
        change: 0.78
      }
    ]
  },

  onLoad(options: any) {
    const symbol = options.symbol || 'AAPL'
    this.setData({
      stockSymbol: symbol
    })
    // 实际应用中根据 symbol 从服务器获取数据
  },

  changeTimePeriod(e: any) {
    const index = e.currentTarget.dataset.index
    this.setData({
      activeTimePeriod: index
    })
  },

  addToWatchlist() {
    wx.showToast({
      title: 'Added to watchlist',
      icon: 'success'
    })
  },

  compare() {
    wx.showToast({
      title: 'Compare feature coming soon',
      icon: 'none'
    })
  },

  viewRelatedStock(e: any) {
    const symbol = e.currentTarget.dataset.symbol
    wx.redirectTo({
      url: `/subpages/stock-detail/stock-detail?symbol=${symbol}`
    })
  },

  buyStock() {
    wx.showToast({
      title: 'Buy order placed',
      icon: 'success'
    })
  },

  sellStock() {
    wx.showToast({
      title: 'Sell order placed',
      icon: 'success'
    })
  }
})
