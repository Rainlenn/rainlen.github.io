// pages/create-post/create-post.ts
Page({
  data: {
    postTitle: '',
    postContent: '',
    images: [] as string[],
    selectedCategory: 0,
    categories: ['General', 'Stock Analysis', 'Market News', 'Q&A', 'Discussion']
  },

  onLoad() {
    // 初始化
  },

  onTitleInput(e: any) {
    this.setData({
      postTitle: e.detail.value
    })
  },

  onContentInput(e: any) {
    this.setData({
      postContent: e.detail.value
    })
  },

  chooseImage() {
    const maxImages = 9
    const currentCount = this.data.images.length
    const remainingSlots = maxImages - currentCount

    wx.chooseImage({
      count: remainingSlots,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: (res) => {
        const newImages = [...this.data.images, ...res.tempFilePaths]
        this.setData({
          images: newImages
        })
      }
    })
  },

  deleteImage(e: any) {
    const index = e.currentTarget.dataset.index
    const images = this.data.images.filter((_, i) => i !== index)
    this.setData({
      images: images
    })
  },

  selectCategory(e: any) {
    const index = e.currentTarget.dataset.index
    this.setData({
      selectedCategory: index
    })
  },

  saveDraft() {
    if (!this.data.postTitle.trim()) {
      wx.showToast({
        title: 'Please enter a title',
        icon: 'none'
      })
      return
    }

    wx.showToast({
      title: 'Draft saved',
      icon: 'success'
    })
  },

  publishPost() {
    if (!this.data.postTitle.trim()) {
      wx.showToast({
        title: 'Please enter a title',
        icon: 'none'
      })
      return
    }

    if (!this.data.postContent.trim()) {
      wx.showToast({
        title: 'Please enter content',
        icon: 'none'
      })
      return
    }

    wx.showToast({
      title: 'Post published!',
      icon: 'success'
    })

    setTimeout(() => {
      wx.navigateBack()
    }, 1500)
  }
})
