# Git 设置指南 (Mac)

## 1. 检查 Git 是否已安装

Git 已经安装在您的系统上（版本 2.50.1）。

## 2. 配置 Git 用户信息（必需）

首次使用 Git 前，需要设置您的用户名和邮箱。您可以选择：

### 方式一：全局配置（推荐）
适用于所有 Git 项目：

```bash
git config --global user.name "您的姓名"
git config --global user.email "您的邮箱@example.com"
```

### 方式二：仅针对当前项目
只对当前项目生效：

```bash
git config user.name "您的姓名"
git config user.email "您的邮箱@example.com"
```

### 验证配置
运行以下命令检查配置是否成功：

```bash
git config --global user.name
git config --global user.email
```

## 3. 当前项目状态

您的项目已经：
- ✅ 初始化了 Git 仓库（`git init`）
- ✅ 创建了 `.gitignore` 文件
- ✅ 文件已暂存（staged），准备提交

## 4. 完成首次提交

运行以下命令完成首次提交：

```bash
# 查看当前状态
git status

# 提交所有已暂存的文件
git commit -m "Initial commit: Add project files and prototype"

# 查看提交历史
git log
```

## 5. 常用 Git 命令

```bash
# 查看状态
git status

# 添加文件到暂存区
git add <文件名>
git add .          # 添加所有文件

# 提交更改
git commit -m "提交信息"

# 查看提交历史
git log
git log --oneline  # 简洁版本

# 查看配置
git config --list
```

## 6. 后续操作（可选）

### 连接到远程仓库（如 GitHub）

```bash
# 添加远程仓库
git remote add origin https://github.com/用户名/仓库名.git

# 推送到远程
git push -u origin main
```

### 创建新分支

```bash
# 创建并切换到新分支
git checkout -b feature/新功能

# 切换分支
git checkout main
```

## 注意事项

- `.gitignore` 文件中列出的文件和文件夹不会被 Git 跟踪
- 您的 `.gitignore` 已正确配置，会忽略 `node_modules`、`.DS_Store` 等文件
- 提交信息要清晰描述本次更改的内容

