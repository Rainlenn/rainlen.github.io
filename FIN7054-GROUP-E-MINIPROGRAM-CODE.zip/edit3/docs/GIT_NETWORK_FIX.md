# Git 网络连接问题解决方案

## 问题描述
```
RPC failed; curl 28 Failed to connect to github.com port 443 after 75001 ms: Couldn't connect to server
```

## 已应用的解决方案 1：增加超时时间 ✅

已为您配置：
- HTTP 缓冲区：500MB
- 超时时间：300秒（5分钟）
- 低速限制：已禁用

## 解决方案 2：使用 SSH 代替 HTTPS（推荐）

### 步骤 1：检查是否已有 SSH 密钥
```bash
ls -al ~/.ssh
```

### 步骤 2：生成 SSH 密钥（如果没有）
```bash
ssh-keygen -t ed25519 -C "your_email@example.com"
# 按 Enter 使用默认路径
# 可以设置密码或直接按 Enter 跳过
```

### 步骤 3：添加 SSH 密钥到 ssh-agent
```bash
eval "$(ssh-agent -s)"
ssh-add ~/.ssh/id_ed25519
```

### 步骤 4：复制公钥
```bash
cat ~/.ssh/id_ed25519.pub
# 复制输出的内容
```

### 步骤 5：添加到 GitHub
1. 访问：https://github.com/settings/keys
2. 点击 "New SSH key"
3. 粘贴公钥内容
4. 保存

### 步骤 6：更改远程仓库为 SSH
```bash
git remote set-url origin git@github.com:Rainlenn/miniprogram-3.git
git remote -v  # 验证更改
```

## 解决方案 3：配置代理（如果使用代理）

### 设置 HTTP/HTTPS 代理
```bash
# 设置代理（替换为您的代理地址和端口）
git config --global http.proxy http://127.0.0.1:7890
git config --global https.proxy http://127.0.0.1:7890

# 仅对 GitHub 使用代理
git config --global http.https://github.com.proxy http://127.0.0.1:7890

# 查看代理设置
git config --global --get http.proxy
git config --global --get https.proxy

# 取消代理设置
git config --global --unset http.proxy
git config --global --unset https.proxy
```

## 解决方案 4：使用 GitHub 镜像（临时方案）

如果在中国大陆，可以使用 GitHub 镜像：

```bash
# 使用镜像地址（需要先确认镜像服务可用）
git config --global url."https://github.com.cnpmjs.org/".insteadOf "https://github.com/"
```

## 解决方案 5：分批推送

如果文件太大，可以尝试分批推送：

```bash
# 先推送少量提交
git push origin main --verbose

# 或者使用浅克隆后再推送
```

## 解决方案 6：检查防火墙和网络

```bash
# 测试 HTTPS 连接
curl -I https://github.com

# 测试 SSH 连接
ssh -T git@github.com
```

## 推荐操作顺序

1. **首先尝试**：重新推送（已增加超时时间）
   ```bash
   git push origin main
   ```

2. **如果仍然失败**：切换到 SSH（最稳定）
   ```bash
   git remote set-url origin git@github.com:Rainlenn/miniprogram-3.git
   git push origin main
   ```

3. **如果使用代理**：配置代理后重试

4. **最后手段**：使用镜像服务

## 验证配置

```bash
# 查看当前远程仓库
git remote -v

# 查看 Git 配置
git config --list | grep -E "(proxy|timeout|buffer)"
```

