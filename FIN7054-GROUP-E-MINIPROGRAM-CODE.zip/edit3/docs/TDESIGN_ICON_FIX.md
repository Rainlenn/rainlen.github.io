# TDesign 图标字体加载问题解决方案

## 问题描述
TDesign 的 icon 组件使用外部字体文件 `https://tdesign.gtimg.com/icon/0.4.0/fonts/t.woff`，在微信小程序中可能无法加载，导致图标无法显示。

## 解决方案

### 方案 1：配置域名白名单（推荐，生产环境必需）

1. 登录 [微信公众平台](https://mp.weixin.qq.com/)
2. 进入 **开发** -> **开发管理** -> **开发设置**
3. 在 **服务器域名** 中添加：
   - `https://tdesign.gtimg.com` 到 **downloadFile 合法域名**
   - `https://tdesign.gtimg.com` 到 **request 合法域名**

### 方案 2：使用图片图标（临时方案）

将 `t-icon` 组件改为使用图片路径：

```xml
<!-- 原代码 -->
<t-icon name="heart" size="32rpx" color="#10b981" />

<!-- 改为图片 -->
<image src="/assets/icons/heart.png" style="width: 32rpx; height: 32rpx;" />
```

### 方案 3：忽略字体错误（开发环境）

字体加载失败不会影响小程序功能，只是图标可能显示为方块或空白。可以在开发阶段暂时忽略此错误。

### 方案 4：使用本地字体文件

1. 下载 TDesign 字体文件到本地
2. 修改 `miniprogram/miniprogram_npm/tdesign-miniprogram/icon/icon.wxss`
3. 将字体路径改为本地路径

## 当前状态

- 小程序功能正常
- 图标可能无法显示（显示为方块或空白）
- 不影响其他功能使用

## 建议

对于生产环境，**必须**在微信公众平台配置域名白名单，否则图标无法正常显示。

